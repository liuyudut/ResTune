import torch.nn as nn
import torch

class VGG_encoder(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_encoder, self).__init__()
        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 1
        self.side1_pool = nn.MaxPool2d(kernel_size=8, stride=8)
        self.side1_label = nn.Sequential(
            nn.Linear(2*2*64, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side1_unlabel = nn.Sequential(
            nn.Linear(2*2*64, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 2
        self.side2_pool = nn.MaxPool2d(kernel_size=4, stride=4)
        self.side2_label = nn.Sequential(
            nn.Linear(2*2*128, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side2_unlabel = nn.Sequential(
            nn.Linear(2*2*128, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 3
        self.side3_pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.side3_label = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side3_unlabel = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.side4_label = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side4_unlabel = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        # fusion module
        self.fusion_label = nn.Sequential(
            nn.Conv2d(4, 1, kernel_size=1, padding=0, bias=False),
            nn.BatchNorm2d(1),
            nn.ReLU(inplace=True)
        )
        self.fusion_label[0].weight.data.fill_(0.25)
        self.fusion_unlabel = nn.Sequential(
            nn.Conv2d(4, 1, kernel_size=1, padding=0, bias=False),
            nn.BatchNorm2d(1),
            nn.ReLU(inplace=True),
        )
        self.fusion_unlabel[0].weight.data.fill_(0.25)
        self.dropout = nn.Dropout(0.5)
        self.last1_label = nn.Linear(512, nclass_label)
        self.last2_label = nn.Linear(512, nclass_label)
        self.last3_label = nn.Linear(512, nclass_label)
        self.last4_label = nn.Linear(512, nclass_label)
        self.last_fusion_label = nn.Linear(512, nclass_label)
        self.last1_unlabel = nn.Linear(512, nclass_unlabel)
        self.last2_unlabel = nn.Linear(512, nclass_unlabel)
        self.last3_unlabel = nn.Linear(512, nclass_unlabel)
        self.last4_unlabel = nn.Linear(512, nclass_unlabel)
        self.last_fusion_unlabel = nn.Linear(512, nclass_unlabel)

    def forward(self, x, flag=0):
        x = self.layer1(x)
        side1_pool = self.side1_pool(x)
        side1_pool = side1_pool.view(side1_pool.size(0), -1)
        side1_label = self.side1_label(side1_pool)
        if flag==1:
            side1_unlabel = self.side1_unlabel(side1_pool)
        ##
        x = self.layer2(x)
        side2_pool = self.side2_pool(x)
        side2_pool = side2_pool.view(side2_pool.size(0), -1)
        side2_label = self.side2_label(side2_pool)
        if flag==1:
            side2_unlabel = self.side2_unlabel(side2_pool)
        ##
        x = self.layer3(x)
        side3_pool = self.side3_pool(x)
        side3_pool = side3_pool.view(side3_pool.size(0), -1)
        side3_label = self.side3_label(side3_pool)
        if flag==1:
            side3_unlabel = self.side3_unlabel(side3_pool)
        ##
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        side4_label = self.side4_label(x)
        if flag==1:
            side4_unlabel = self.side4_unlabel(x)
        ##
        side1_out = self.last1_label(side1_label)
        side2_out = self.last2_label(side2_label)
        side3_out = self.last3_label(side3_label)
        side4_out = self.last4_label(side4_label)
        ## label fusion
        side1_label_re = torch.unsqueeze(side1_label, 2)
        side2_label_re = torch.unsqueeze(side2_label, 2)
        side3_label_re = torch.unsqueeze(side3_label, 2)
        side4_label_re = torch.unsqueeze(side4_label, 2)
        fusion_label = torch.cat((side1_label_re, side2_label_re, side3_label_re, side4_label_re), 2)
        fusion_label = fusion_label.transpose(1, 2)
        fusion_label = torch.unsqueeze(fusion_label, 3)
        fusion_label = self.fusion_label(fusion_label)
        fusion_label = fusion_label.view(fusion_label.size(0), -1)

        if flag==0:
            fusion_label = self.dropout(fusion_label)
            fusion_out = self.last_fusion_label(fusion_label)
            ##
            feats = []
            feats.append(side1_label)
            feats.append(side2_label)
            feats.append(side3_label)
            feats.append(side4_label)
            feats.append(fusion_label)
            outs = []
            outs.append(side1_out)
            outs.append(side2_out)
            outs.append(side3_out)
            outs.append(side4_out)
            outs.append(fusion_out)
            return feats, outs
        elif flag==1:
            side1_feat = side1_label + side1_unlabel
            side2_feat = side2_label + side2_unlabel
            side3_feat = side3_label + side3_unlabel
            side4_feat = side4_label + side4_unlabel
            ## label outputs
            side1_out_label = self.last1_label(side1_feat)
            side2_out_label = self.last2_label(side2_feat)
            side3_out_label = self.last3_label(side3_feat)
            side4_out_label = self.last4_label(side4_feat)
            ## unlabel outputs
            side1_out_unlabel = self.last1_unlabel(side1_feat)
            side2_out_unlabel = self.last2_unlabel(side2_feat)
            side3_out_unlabel = self.last3_unlabel(side3_feat)
            side4_out_unlabel = self.last4_unlabel(side4_feat)
            ## set
            feats_label = []
            feats_label.append(side1_label)
            feats_label.append(side2_label)
            feats_label.append(side3_label)
            feats_label.append(side4_label)
            feats_label.append(fusion_label)
            feats_unlabel = []
            feats_unlabel.append(side1_unlabel)
            feats_unlabel.append(side2_unlabel)
            feats_unlabel.append(side3_unlabel)
            feats_unlabel.append(side4_unlabel)
            outs_label = []
            outs_label.append(side1_out_label)
            outs_label.append(side2_out_label)
            outs_label.append(side3_out_label)
            outs_label.append(side4_out_label)
            outs_unlabel = []
            outs_unlabel.append(side1_out_unlabel)
            outs_unlabel.append(side2_out_unlabel)
            outs_unlabel.append(side3_out_unlabel)
            outs_unlabel.append(side4_out_unlabel)

            return feats_label, feats_unlabel, outs_label, outs_unlabel
