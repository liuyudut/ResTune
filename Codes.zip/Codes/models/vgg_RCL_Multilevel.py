import torch.nn as nn
import torch

class VGG_encoder(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_encoder, self).__init__()

        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc_label = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.last_label = nn.Linear(512, nclass_label)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        fc_label = self.fc_label(x)
        out_label = self.last_label(fc_label)

        return fc_label, out_label




class VGG_encoder_multilevel(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_encoder_multilevel, self).__init__()
        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 1
        self.side1_pool = nn.MaxPool2d(kernel_size=8, stride=8)
        self.side1_unlabel = nn.Sequential(
            nn.Linear(2*2*64, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 2
        self.side2_pool = nn.MaxPool2d(kernel_size=4, stride=4)
        self.side2_unlabel = nn.Sequential(
            nn.Linear(2*2*128, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 3
        self.side3_pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.side3_unlabel = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc_label = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.fc_unlabel = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side1_alpha = nn.Sequential(
            nn.Linear(2*2*64, 512),
            nn.BatchNorm1d(512),
            nn.Sigmoid()
        )
        self.side2_alpha = nn.Sequential(
            nn.Linear(2*2*128, 512),
            nn.BatchNorm1d(512),
            nn.Sigmoid()
        )
        self.side3_alpha = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.Sigmoid()
        )
        self.side4_alpha = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.Sigmoid()
        )
        self.last_label = nn.Linear(512, nclass_label)
        self.last_unlabel = nn.Linear(512, nclass_unlabel)
        self.center = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))
        # self.fusion_unlabel = nn.Sequential(
        #     nn.Conv2d(4, 1, kernel_size=1, padding=0, bias=False),
        #     nn.BatchNorm2d(1),
        #     nn.ReLU(inplace=True),
        # )
        # self.fusion_unlabel[0].weight.data.fill_(0.25)
        self.fc_concat = nn.Sequential(
            nn.Linear(512*4, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.dropout = nn.Dropout(0.5)

    def forward(self, x, flag=0):
        x = self.layer1(x)
        if flag==1:
            side1_pool = self.side1_pool(x)
            side1_pool = side1_pool.view(side1_pool.size(0), -1)
            side1_unlabel = self.side1_unlabel(side1_pool)
            #side1_alpha = self.side1_alpha(side1_pool)
        #
        x = self.layer2(x)
        if flag==1:
            side2_pool = self.side2_pool(x)
            side2_pool = side2_pool.view(side2_pool.size(0), -1)
            side2_unlabel = self.side2_unlabel(side2_pool)
            #side2_alpha = self.side2_alpha(side2_pool)
        #
        x = self.layer3(x)
        if flag==1:
            side3_pool = self.side3_pool(x)
            side3_pool = side3_pool.view(side3_pool.size(0), -1)
            side3_unlabel = self.side3_unlabel(side3_pool)
            #side3_alpha = self.side3_alpha(side3_pool)
        #
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        fc_label = self.fc_label(x)
        if flag==1:
            side4_unlabel = self.fc_unlabel(x)
            side4_alpha = self.side4_alpha(x)
        ##
        if flag==0:
            out_label = self.last_label(fc_label)

            return fc_label, out_label
        elif flag==1:
            #alpha = self.alpha(x)
            #alpha = torch.sigmoid(alpha)
            #side_unlabel = side1_unlabel + side2_unlabel + side3_unlabel + side4_unlabel
            #feat_unlabel = fc_label + side4_alpha*side_unlabel
            # side1_unlabel = torch.unsqueeze(side1_unlabel, 2)
            # side2_unlabel = torch.unsqueeze(side2_unlabel, 2)
            # side3_unlabel = torch.unsqueeze(side3_unlabel, 2)
            # side4_unlabel = torch.unsqueeze(side4_unlabel, 2)
            # fusion_unlabel = torch.cat((side1_unlabel, side2_unlabel, side3_unlabel, side4_unlabel), 2)
            # fusion_unlabel = fusion_unlabel.transpose(1, 2)
            # fusion_unlabel = torch.unsqueeze(fusion_unlabel, 3)
            # fusion_unlabel = self.fusion_unlabel(fusion_unlabel)
            # fusion_unlabel = fusion_unlabel.view(fusion_unlabel.size(0), -1)
            #side_unlabel = (side1_unlabel + side2_unlabel + side3_unlabel + side4_unlabel) / 4
            ## concat feature
            concat_unlabel = torch.cat((side1_unlabel, side2_unlabel, side3_unlabel, side4_unlabel), 1)
            fusion_unlabel = self.fc_concat(concat_unlabel)

            feat_unlabel = (1-side4_alpha) * fc_label + side4_alpha * fusion_unlabel
            out_label = self.last_label(fc_label)
            #feat_unlabel = self.dropout(feat_unlabel)
            out_unlabel = self.last_unlabel(feat_unlabel)

            return fc_label, feat_unlabel, out_label, out_unlabel

