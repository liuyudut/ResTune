import torch.nn as nn
import torch

# class VGG(nn.Module):
#     cfg = {
#         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
#         '5+1': [64, 'M', 128, 'M', 256, 'M', 512, 'M', 512, 'M'],
#     }
#     # these two 6-layer variants of VGG are following https://arxiv.org/abs/1711.10125 and https://github.com/GT-RIPL/L2C/blob/master/models/vgg.py
#     def __init__(self, n_layer='4+2', out_dim=10, in_channels=3, img_sz=32):
#         super(VGG, self).__init__()
#         self.conv_func = nn.Conv2d
#         self.features = self._make_layers(VGG.cfg[n_layer],in_channels)
#         if n_layer=='4+2':
#             self.feat_map_sz = img_sz // 16
#             feat_dim = 256*(self.feat_map_sz**2)
#             self.last = nn.Sequential(
#                 nn.Linear(feat_dim, feat_dim//2),
#                 nn.BatchNorm1d(feat_dim//2),
#                 nn.ReLU(inplace=True),
#                 nn.Linear(feat_dim//2, out_dim)
#             )
#             self.last.in_features = feat_dim
#         elif n_layer=='5+1':
#             self.feat_map_sz = img_sz // 32
#             self.last = nn.Linear(512*(self.feat_map_sz**2), out_dim)
#
#     def _make_layers(self, cfg, in_channels):
#         layers = []
#         for x in cfg:
#             if x == 'M':
#                 layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
#             else:
#                 layers += [nn.Conv2d(in_channels, x, kernel_size=3, padding=1),
#                            nn.BatchNorm2d(x),
#                            nn.ReLU(inplace=True)]
#                 in_channels = x
#         return nn.Sequential(*layers)
#
#     def forward(self, x):
#         x = self.features(x)
#         x = x.view(x.size(0), -1)
#         out = self.last(x)
#         return x, out

class VGG_net(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_net, self).__init__()

        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.last_label = nn.Linear(512, nclass_label)
        self.last_unlabel = nn.Linear(512, nclass_unlabel)
        self.center = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))

    def forward(self, x, flag=0):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        fc = self.fc(x)
        if flag==0:
            out_label = self.last_label(fc)
            return fc, out_label
        elif flag==1:
            out_label = self.last_label(fc)
            out_unlabel = self.last_unlabel(fc)
            return fc, out_label, out_unlabel

class VGG_net_more(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_net_more, self).__init__()

        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.last_label = nn.Linear(512, nclass_label)
        self.last_unlabel_A = nn.Linear(512, nclass_unlabel)
        self.last_unlabel_B = nn.Linear(512, nclass_unlabel)
        self.center_A = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))
        self.center_B = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))

    def forward(self, x, flag=0):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        fc = self.fc(x)
        if flag==0:
            out_label = self.last_label(fc)
            return fc, out_label
        elif flag==1:
            out_label = self.last_label(fc)
            out_unlabel = self.last_unlabel_A(fc)
            return fc, out_label, out_unlabel
        elif flag==2:
            out_label = self.last_label(fc)
            out_unlabel_A = self.last_unlabel_A(fc)
            out_unlabel_B = self.last_unlabel_B(fc)
            return fc, out_label, out_unlabel_A, out_unlabel_B

class VGG_tinyimagenet(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_tinyimagenet, self).__init__()

        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer5 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc = nn.Sequential(
            nn.Linear(2048, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.last_label = nn.Linear(512, nclass_label)
        self.last_unlabel = nn.Linear(512, nclass_unlabel)
        self.center = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))

    def forward(self, x, flag=0):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)
        x = x.view(x.size(0), -1)
        fc = self.fc(x)
        if flag==0:
            out_label = self.last_label(fc)
            return fc, out_label
        elif flag==1:
            out_label = self.last_label(fc)
            out_unlabel = self.last_unlabel(fc)
            return fc, out_label, out_unlabel