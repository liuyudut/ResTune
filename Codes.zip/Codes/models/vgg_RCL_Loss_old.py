import torch.nn as nn
import torch

class VGG_encoder(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_encoder, self).__init__()
        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 1
        self.side1_pool = nn.MaxPool2d(kernel_size=8, stride=8)
        self.side1_label = nn.Sequential(
            nn.Linear(2*2*64, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side1_unlabel = nn.Sequential(
            nn.Linear(2*2*64, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 2
        self.side2_pool = nn.MaxPool2d(kernel_size=4, stride=4)
        self.side2_label = nn.Sequential(
            nn.Linear(2*2*128, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side2_unlabel = nn.Sequential(
            nn.Linear(2*2*128, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        ## side branch 3
        self.side3_pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.side3_label = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side3_unlabel = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.side4_label = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.side4_unlabel = nn.Sequential(
            nn.Linear(2*2*256, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        #self.dropout = nn.Dropout(0.5)
        self.last1_label = nn.Linear(512, nclass_label)
        self.last2_label = nn.Linear(512, nclass_label)
        self.last3_label = nn.Linear(512, nclass_label)
        self.last4_label = nn.Linear(512, nclass_label)
        self.last1_unlabel = nn.Linear(512, nclass_unlabel)
        self.last2_unlabel = nn.Linear(512, nclass_unlabel)
        self.last3_unlabel = nn.Linear(512, nclass_unlabel)
        self.last4_unlabel = nn.Linear(512, nclass_unlabel)
        #
        self.alpha_side1 = nn.Linear(2*2*64, 512)
        self.alpha_side2 = nn.Linear(2*2*128, 512)
        self.alpha_side3 = nn.Linear(2*2*256, 512)
        self.alpha_side4 = nn.Linear(2*2*256, 512)
        #
        self.center_side1 = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))
        self.center_side2 = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))
        self.center_side3 = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))
        self.center_side4 = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))


    def forward(self, x, flag=0):
        x = self.layer1(x)
        side1_pool = self.side1_pool(x)
        side1_pool = side1_pool.view(side1_pool.size(0), -1)
        side1_label = self.side1_label(side1_pool)
        if flag==1:
            side1_unlabel = self.side1_unlabel(side1_pool)
            side1_alpha = self.alpha_side1(side1_pool)
            side1_alpha = torch.sigmoid(side1_alpha)
        ##
        x = self.layer2(x)
        side2_pool = self.side2_pool(x)
        side2_pool = side2_pool.view(side2_pool.size(0), -1)
        side2_label = self.side2_label(side2_pool)
        if flag==1:
            side2_unlabel = self.side2_unlabel(side2_pool)
            side2_alpha = self.alpha_side2(side2_pool)
            side2_alpha = torch.sigmoid(side2_alpha)
        ##
        x = self.layer3(x)
        side3_pool = self.side3_pool(x)
        side3_pool = side3_pool.view(side3_pool.size(0), -1)
        side3_label = self.side3_label(side3_pool)
        if flag==1:
            side3_unlabel = self.side3_unlabel(side3_pool)
            side3_alpha = self.alpha_side3(side3_pool)
            side3_alpha = torch.sigmoid(side3_alpha)
        ##
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        side4_label = self.side4_label(x)
        if flag==1:
            side4_unlabel = self.side4_unlabel(x)
            side4_alpha = self.alpha_side4(x)
            side4_alpha = torch.sigmoid(side4_alpha)
        ##
        if flag==0:
            #
            side1_out = self.last1_label(side1_label)
            side2_out = self.last2_label(side2_label)
            side3_out = self.last3_label(side3_label)
            side4_out = self.last4_label(side4_label)
            ##
            feats = []
            feats.append(side1_label)
            feats.append(side2_label)
            feats.append(side3_label)
            feats.append(side4_label)
            outs = []
            outs.append(side1_out)
            outs.append(side2_out)
            outs.append(side3_out)
            outs.append(side4_out)
            return feats, outs
        elif flag==1:
            side1_feat = (1 - side1_alpha) * side4_label + side1_alpha * side1_unlabel
            side2_feat = (1 - side2_alpha) * side4_label + side2_alpha * side2_unlabel
            side3_feat = (1 - side3_alpha) * side4_label + side3_alpha * side3_unlabel
            side4_feat = (1 - side4_alpha) * side4_label + side4_alpha * side4_unlabel
            ## label outputs
            side1_out_label = self.last1_label(side1_label)
            side2_out_label = self.last2_label(side2_label)
            side3_out_label = self.last3_label(side3_label)
            side4_out_label = self.last4_label(side4_label)
            ## unlabel outputs
            side1_out_unlabel = self.last1_unlabel(side1_feat)
            side2_out_unlabel = self.last2_unlabel(side2_feat)
            side3_out_unlabel = self.last3_unlabel(side3_feat)
            side4_out_unlabel = self.last4_unlabel(side4_feat)
            ## set
            feats_label = []
            feats_label.append(side1_label)
            feats_label.append(side2_label)
            feats_label.append(side3_label)
            feats_label.append(side4_label)
            feats_unlabel = []
            feats_unlabel.append(side1_unlabel)
            feats_unlabel.append(side2_unlabel)
            feats_unlabel.append(side3_unlabel)
            feats_unlabel.append(side4_unlabel)
            outs_label = []
            outs_label.append(side1_out_label)
            outs_label.append(side2_out_label)
            outs_label.append(side3_out_label)
            outs_label.append(side4_out_label)
            outs_unlabel = []
            outs_unlabel.append(side1_out_unlabel)
            outs_unlabel.append(side2_out_unlabel)
            outs_unlabel.append(side3_out_unlabel)
            outs_unlabel.append(side4_out_unlabel)

            return feats_label, feats_unlabel, outs_label, outs_unlabel


class VGG_decoder(nn.Module):
    def __init__(self, inputsize):
        super(VGG_decoder, self).__init__()
        ncha,size,_=inputsize
        ##
        self.fc = nn.Sequential(
            nn.Linear(512, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(inplace=True)
        )
        self.layer1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True)
        )
        self.layer2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )
        self.layer3 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.layer4 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.img = nn.Conv2d(64, ncha, kernel_size=3, padding=1)

    def forward(self, x):
        x = self.fc(x) # 512->1024
        x = x.view(x.size(0), -1, 2, 2) # 2*2*256
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        img = self.img(x)

        return img
