import torch.nn as nn
import torch

# class VGG_encoder(nn.Module):
#     #     cfg = {
#     #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
#     #     }
#     def __init__(self, inputsize, nclass_label, nclass_unlabel):
#         super(VGG_encoder, self).__init__()
#
#         ncha,size,_=inputsize
#         self.layer1 = nn.Sequential(
#             nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
#             nn.BatchNorm2d(64),
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2)
#         )
#         self.layer2 = nn.Sequential(
#             nn.Conv2d(64, 128, kernel_size=3, padding=1),
#             nn.BatchNorm2d(128),
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2)
#         )
#         self.layer3 = nn.Sequential(
#             nn.Conv2d(128, 256, kernel_size=3, padding=1),
#             nn.BatchNorm2d(256),
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2)
#         )
#         self.layer4 = nn.Sequential(
#             nn.Conv2d(256, 256, kernel_size=3, padding=1),
#             nn.BatchNorm2d(256),
#             nn.ReLU(inplace=True),
#             nn.MaxPool2d(kernel_size=2, stride=2)
#         )
#         self.fc_label = nn.Sequential(
#             nn.Linear(1024, 512),
#             nn.BatchNorm1d(512),
#             nn.ReLU(inplace=True)
#         )
#         self.last_label = nn.Linear(512, nclass_label)
#
#     def forward(self, x):
#         x = self.layer1(x)
#         x = self.layer2(x)
#         x = self.layer3(x)
#         x = self.layer4(x)
#         x = x.view(x.size(0), -1)
#         fc_label = self.fc_label(x)
#         out_label = self.last_label(fc_label)
#
#         return fc_label, out_label


class VGG_net(nn.Module):
    #     cfg = {
    #         '4+2': [64, 'M', 128, 'M', 256, 'M', 256, 'M'],
    #     }
    def __init__(self, inputsize, nclass_label, nclass_unlabel):
        super(VGG_net, self).__init__()

        ncha,size,_=inputsize
        self.layer1 = nn.Sequential(
            nn.Conv2d(ncha, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.layer4 = nn.Sequential(
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc_label = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        self.fc_unlabel = nn.Sequential(
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True)
        )
        # self.alpha = nn.Sequential(
        #     nn.Linear(1024, 512),
        #     nn.BatchNorm1d(512),
        #     nn.Sigmoid()
        # )
        self.last_label = nn.Linear(512, nclass_label)
        self.last_pairwise = nn.Linear(512, nclass_unlabel)
        self.last_pca = nn.Linear(512, nclass_unlabel)
        self.center = nn.Parameter(torch.Tensor(nclass_unlabel, nclass_unlabel))

    def forward(self, x, flag=0):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = x.view(x.size(0), -1)
        fc_label = self.fc_label(x)
        #fc_unlabel = self.fc_unlabel(x)
        if flag==0:
            out_label = self.last_label(fc_label)
            return fc_label, out_label
        elif flag==1:
            # alpha = self.alpha(x)
            # alpha = torch.unsqueeze(alpha, 2)
            # alpha = alpha.view(x.size(0), 512, 2)
            # alpha = torch.softmax(alpha, dim=2)
            # fc = alpha[:,:,0]*fc_label + alpha[:,:,1]*fc_unlabel
            #alpha = self.alpha(x)
            #fc = alpha*fc_label + (1-alpha)*fc_unlabel
            #fc = fc_label + alpha*fc_unlabel
            out_label = self.last_label(fc_label)
            out_pca = self.last_pca(fc_label)
            out_pairwise = self.last_pairwise(fc_label)

            return fc_label, out_label, out_pca, out_pairwise




