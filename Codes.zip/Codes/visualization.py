# from sklearn import manifold, datasets
# import time
# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# import matplotlib.patheffects as PathEffects
#
# import seaborn as sns
# sns.set_style('darkgrid')
# sns.set_palette('muted')
# sns.set_context("notebook", font_scale=1.5, rc={"lines.linewidth": 1})
# RS = 123
#
# def vis_scatter(x, colors):
#     # choose a color palette with seaborn.
#     num_classes = len(np.unique(colors))
#     palette = np.array(sns.color_palette("hls", num_classes))
#
#     # create a scatter plot.
#     f = plt.figure(figsize=(4, 4))
#     ax = plt.subplot(aspect='equal')
#     sc = ax.scatter(x[:,0], x[:,1], lw=0, s=40, c=palette[colors.astype(np.int)])
#     ax.axis('tight')
#     #ax.axis('off')
#
#     # add the labels for each digit corresponding to the label
#     txts = []
#
#     for i in range(num_classes):
#
#         # Position of each label at median of data points.
#
#         xtext, ytext = np.median(x[colors == i, :], axis=0)
#         txt = ax.text(xtext, ytext, str(i), fontsize=24)
#         txt.set_path_effects([
#             PathEffects.Stroke(linewidth=5, foreground="w"),
#             PathEffects.Normal()])
#         txts.append(txt)
#
#     return f, ax, sc, txts
#
#
# ##
# digits = datasets.load_digits(n_class=6)
# X, y = digits.data, digits.target
# n_samples, n_features = X.shape
#
#
# '''t-SNE'''
# tsne = manifold.TSNE(n_components=2, init='pca', random_state=501)
# X_tsne = tsne.fit_transform(X)
#
# vis_scatter(X_tsne, y)
# plt.show()
#
# # '''显示原始数据'''
# # n = 20  # 每行20个数字，每列20个数字
# # img = np.zeros((10 * n, 10 * n))
# # for i in range(n):
# #     ix = 10 * i + 1
# #     for j in range(n):
# #         iy = 10 * j + 1
# #         img[ix:ix + 8, iy:iy + 8] = X[i * n + j].reshape((8, 8))
# # plt.figure(figsize=(8, 8))
# # plt.imshow(img, cmap=plt.cm.binary)
# # plt.xticks([])
# # plt.yticks([])
# # plt.show()
# #
# # print("Org data dimension is {}. Embedded data dimension is {}".format(X.shape[-1], X_tsne.shape[-1]))
# # '''嵌入空间可视化'''
# # x_min, x_max = X_tsne.min(0), X_tsne.max(0)
# # X_norm = (X_tsne - x_min) / (x_max - x_min)
# # plt.figure(figsize=(8, 8))
# # for i in range(X_norm.shape[0]):
# #     plt.text(X_norm[i, 0], X_norm[i, 1], str(y[i]), color=plt.cm.Set1(y[i]),fontdict={'weight': 'bold', 'size': 9})
# # plt.xticks([])
# # plt.yticks([])
# # plt.show()
#

"""
==========================
tSNE to visualize digits
==========================

Here we use :class:`sklearn.manifold.TSNE` to visualize the digits
datasets. Indeed, the digits are vectors in a 8*8 = 64 dimensional space.
We want to project them in 2D for visualization. tSNE is often a good
solution, as it groups and separates data points based on their local
relationship.

"""

############################################################
# Load the iris data
from sklearn import datasets
import numpy as np
import scipy.io as sio

matcontent = sio.loadmat("./ResNovel_Results/t-sne/resnet18_cifar10_DTC_unlabel_5_features_test.mat")
feats = np.array(matcontent['feats'])
labels = np.array(matcontent['label']).astype(int).squeeze() - 5
num_classes = len(np.unique(labels))
############################################################
# Fit and transform with a TSNE
from sklearn.manifold import TSNE
tsne = TSNE(n_components=2, init='pca', random_state=1988)

############################################################
# Project the data in 2D
X_2d = tsne.fit_transform(feats)

############################################################
# Visualize the data
target_ids = range(num_classes)

from matplotlib import pyplot as plt
import matplotlib.patheffects as PathEffects
plt.figure(figsize=(4, 4))
colors = 'r', 'g', 'b', 'm', 'y'
for i, c in zip(target_ids, colors):
    plt.scatter(X_2d[labels == i, 0], X_2d[labels == i, 1], s=10, c=c, marker='o')
#plt.legend()

txts = []
names = 'dog', 'frog', 'horse', 'ship', 'truck'
for i in range(num_classes):
    # Position of each label at median of data points.
    xtext, ytext = np.median(X_2d[labels == i, :], axis=0)
    txt = plt.text(xtext, ytext, names[i], fontsize=16, color=colors[i])
    txt.set_path_effects([PathEffects.Stroke(linewidth=2, foreground="w"),PathEffects.Normal()])
    txts.append(txt)

plt.axis('off')
plt.show()
