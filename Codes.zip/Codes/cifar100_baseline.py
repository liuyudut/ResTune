import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.optim import SGD, lr_scheduler
from torch.autograd import Variable
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from utils.util import BCE, PairEnum, cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.vgg_RCL_baseline import VGG_net
from modules.module import feat2prob, target_distribution
from data.cifarloader import CIFAR100Loader
from tqdm import tqdm
import numpy as np
import warnings
import os
import scipy.io as sio
import copy
from copy import deepcopy
import torch.nn.functional as func

#warnings.filterwarnings("ignore", category=UserWarning)
class HLoss(nn.Module):
    def __init__(self):
        super(HLoss, self).__init__()
        self.logsoft = nn.LogSoftmax(dim=1)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x, neg=True, batch=False):
        b = self.softmax(x) * self.logsoft(x)
        if batch:
            return -1.0 * b.sum(1)
        if neg:
            return -1.0 * b.sum()/x.size(0)
        else:
            return b.sum()/x.size(0)

def init_prob_kmeans(model, eval_loader, args):
    torch.manual_seed(args.seed)
    #model = model.to(args.device)
    # cluster parameter initiate
    model.eval()
    targets = np.zeros(len(eval_loader.dataset))
    feats = np.zeros((len(eval_loader.dataset), 512))
    with torch.no_grad():
        for _, (x, label, idx) in enumerate(eval_loader):
            x = x.to(args.device)
            feat_label, _ = model(x)
            idx = idx.data.cpu().numpy()
            feats[idx, :] = feat_label.data.cpu().numpy()
            targets[idx] = label.data.cpu().numpy()
    # evaluate clustering performance
    pca = PCA(n_components=args.n_pca)
    feats = pca.fit_transform(feats)
    kmeans = KMeans(n_clusters=args.n_clusters, n_init=20)
    y_pred = kmeans.fit_predict(feats)
    ##
    #targets = targets - meta
    acc, nmi, ari = cluster_acc(targets, y_pred), nmi_score(targets, y_pred), ari_score(targets, y_pred)
    print('Init acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    probs = feat2prob(torch.from_numpy(feats), torch.from_numpy(kmeans.cluster_centers_))
    return acc, nmi, ari, kmeans.cluster_centers_, probs


def compute_sim_loss(feat_old, feat_new, sim_criterion, args):
    feat_old = func.normalize(feat_old, p=2, dim=1)
    feat_new = func.normalize(feat_new, p=2, dim=1)
    one_batch = torch.ones(feat_new.size(0)).to(args.device)
    sim_loss = sim_criterion(feat_old, feat_new, one_batch)

    return sim_loss


def train(old_model, encoder_model, train_loader, eva_loader, args):
    mse_criterion = torch.nn.MSELoss().to(args.device)
    bce_criterion = torch.nn.BCEWithLogitsLoss().to(args.device)
    entropy_criterion = HLoss().to(args.device)
    bce_criterion = BCE().to(args.device)
    optimizer = SGD(encoder_model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    #w = 0
    for epoch in range(args.epochs):
        total_loss_record = AverageMeter()
        cluster_loss_record = AverageMeter()
        rank_loss_record = AverageMeter()
        reg_loss_record = AverageMeter()
        encoder_model.train()
        old_model.eval()
        exp_lr_scheduler.step()
        #w = args.rampup_coefficient * ramps.sigmoid_rampup(epoch, args.rampup_length)
        for batch_idx, ((x, x_bar), label, idx) in enumerate(tqdm(train_loader)):
            x, x_bar = x.to(args.device), x_bar.to(args.device)
            feat_label, out_label, out_pca, out_unlabel = encoder_model(x, flag=1)
            #feat_label_bar, feat_unlabel_bar, out_label_bar, out_unlabel_bar = encoder_model(x_bar, flag=1)
            prob_pca = feat2prob(out_pca, encoder_model.center)
            prob = F.softmax(out_unlabel, dim=1)
            #prob_bar = feat2prob(out_unlabel_bar, encoder_model.center)
            ## clustering loss
            sharp_loss = F.kl_div(prob_pca.log(), args.p_targets[idx].float().to(args.device))

            ## rank loss
            feat_copy = feat_label.detach()
            feat_copy = func.normalize(feat_copy, p=2, dim=1)
            sim_mat = feat_copy.mm(feat_copy.t())

            rank_idx = torch.argsort(sim_mat, dim=1, descending=True)
            rank_idx = rank_idx[:, :args.topk]
            target_ulb = -torch.ones_like(sim_mat).float().to(args.device)
            for i in range(x.size(0)):
                target_ulb[i, rank_idx[i,:]] = 1
            target_ulb = target_ulb.view(-1)
            prob_mat = prob.mm(prob.t())
            prob_mat = prob_mat.view(-1)

            rank_loss = bce_criterion(prob_mat, target_ulb)

            # LwF loss
            _, ref_output = old_model(x)
            soft_target = F.softmax(ref_output / 2, dim=1)
            new_output = old_model.last_label(feat_label)
            logp = F.log_softmax(new_output / 2, dim=1)
            reg_loss = -torch.mean(torch.sum(soft_target * logp, dim=1))  # * args.T * args.T
            #
            ## total loss
            loss = sharp_loss + rank_loss + reg_loss #+ entropy_loss # #+ diff_loss + reconst_loss
            ##
            total_loss_record.update(loss.item(), x.size(0))
            cluster_loss_record.update(sharp_loss.item(), x.size(0))
            rank_loss_record.update(sharp_loss.item(), x.size(0))
            reg_loss_record.update(sharp_loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {}, Center {:.4f}, cluster Loss: {:.4f}, rank Loss: {:.4f}, feat_unlabel: {:.4f}'.format(epoch,
                torch.mean(encoder_model.center), cluster_loss_record.avg, rank_loss_record.avg, torch.mean(feat_label)))
        ##
        encoder_model.eval()
        _, _, _, probs = eval_unlabel_classes(encoder_model, eva_loader, args)

        if (epoch+1) % args.update_interval == 0: ## it is epoch+1 instead of epoch !!
            print('updating target ...')
            args.p_targets = target_distribution(probs)

        if epoch%50==0:
            torch.save(encoder_model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))
            sio.savemat(args.save_clusters_path, {'clusters': encoder_model.center.data.cpu().numpy()})

def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    preds_rank = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            #out = model(x, head=1)
            feat_label, out_label, out_pca, _ = model(x, flag=1)
            prob_pca = feat2prob(out_pca, model.center)
            _, pred_pca = prob_pca.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            #
            # _, pred_rank = out_unlabel.max(1)
            # preds_rank = np.append(preds_rank, pred_rank.cpu().numpy())

            idx = idx.data.cpu().numpy()
            #feats[idx, :] = feat.cpu().detach().numpy()

            probs_pca[idx, :] = prob_pca.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[K-means: Unlabel Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
        ##
        # acc, nmi, ari = cluster_acc(targets.astype(int), preds_rank.astype(int)), nmi_score(targets, preds_rank), ari_score(targets,
        #                                                                                                           preds_rank)
        # print('[Pairwise rank: Unlabel Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
        probs_pca = torch.from_numpy(probs_pca)

    return acc, nmi, ari, probs_pca


def eval_label_classes(model, test_loader, args):
    model.eval()
    preds=np.array([])
    targets=np.array([])
    with torch.no_grad():
        for batch_idx, (x, label, _) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, _, _ = model(x, flag=1)
            out_label = F.softmax(out_label, dim=1)
            _, pred = out_label.max(1)
            targets=np.append(targets, label.cpu().numpy())
            preds=np.append(preds, pred.cpu().numpy())
        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets, preds)
        print('[Label Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_all_classes(model, test_loader, args):
    model.eval()
    preds=np.array([])
    targets=np.array([])
    with torch.no_grad():
        for batch_idx, (x, label, _) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            feat_label, out_label, out_pca, _ = model(x, flag=1)
            out_pca = feat2prob(out_pca, model.center)
            ##
            #out_label = F.softmax(out_label, dim=1)
            #out_unlabel = F.softmax(out_unlabel, dim=1)
            #out_pca = F.softmax(out_pca, dim=1)
            output = torch.cat([out_label, out_pca], 1)
            _, pred = output.max(1)
            targets=np.append(targets, label.cpu().numpy())
            preds=np.append(preds, pred.cpu().numpy())
        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets, preds)
        print('[All Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_all_classes_refine(model, test_loader, args):
    model.eval()
    preds=np.array([])
    targets=np.array([])
    with torch.no_grad():
        for batch_idx, (x, label, _) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, _, out_label, out_unlabel, _ = model(x, flag=1)
            ##
            #out_unlabel = F.softmax(out_unlabel, dim=1)
            #out_unlabel = out_unlabel * args.ratio
            #out_label = F.softmax(out_label, dim=1)
            output = torch.cat([out_label, out_unlabel], 1)
            _, pred = output.max(1)
            targets=np.append(targets, label.cpu().numpy())
            preds=np.append(preds, pred.cpu().numpy())
        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets, preds)
        print('[All Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def extract_feature(model, test_loader, args):
    model.eval()
    feat_label_set = np.zeros((len(test_loader.dataset), 512))
    feat_unlabel_set = np.zeros((len(test_loader.dataset), 512))
    label_set = np.zeros((len(test_loader.dataset)))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            feat_label, feat_unlabel, _, _, _ = model(x, flag=1)
            idx = idx.data.cpu().numpy()
            feat_label_set[idx, :] = feat_label.cpu().detach().numpy()
            feat_unlabel_set[idx, :] = feat_unlabel.cpu().detach().numpy()
            label_set[idx] = label.cpu().detach().numpy()

    sio.savemat(args.save_features_path, {'feat_label_set': feat_label_set, 'feat_unlabel_set': feat_unlabel_set,
                                          'label_set': label_set})


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='cluster',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--warmup_flag', default=False, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--warmup_lr', type=float, default=0.05)
    parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--warmup_epochs', default=30, type=int)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=5, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    parser.add_argument('--milestones', default=[20, 40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--update_interval', default=50, type=int) ## may be important?
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--num_labeled_classes', default=80, type=int)
    parser.add_argument('--n_clusters', default=20, type=int)
    parser.add_argument('--n_pca', default=20, type=int)
    parser.add_argument('--topk', default=5, type=int)
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--alpha', type=float, default=0.5)
    parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    #parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/cifar100_classif_New/cifar100_vgg4+2_label_80.pth')
    parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/cifar100_label_pretrain/vgg4+2_cifar100_ResNovel_label_80.pth')
    parser.add_argument('--dataset_root', type=str, default='./data/datasets/CIFAR/')
    parser.add_argument('--exp_root', type=str, default='./data/experiments/')
    parser.add_argument('--model_name', type=str, default='vgg4+2_cifar100_Baseline_with_kmeans_pairwise_LwF_label_80_unlabel_20.pth')
    parser.add_argument('--save_txt_name', type=str, default='Results_vgg4+2_cifar100_Baseline_with_kmeans_pairwise_LwF_label_80_unlabel_20.pth.txt')
    parser.add_argument('--save_clusters_name', type=str, default='Clusters_vgg4+2_cifar100_Baseline_with_kmeans_pairwise_LwF_label_80_unlabel_20.pth.mat')
    parser.add_argument('--save_feature_name', type=str,
                        default='ResNovel_unlabel_20_features.mat')
    parser.add_argument('--mode', type=str, default='train')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir = args.exp_root + '{}'.format(runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir + '/' + args.model_name
    args.save_txt_path = args.exp_root + '{}/{}'.format(runner_name, args.save_txt_name)
    args.save_clusters_path = args.exp_root + '{}/{}'.format(runner_name, args.save_clusters_name)
    args.save_features_path = args.exp_root + '{}/{}'.format(runner_name, args.save_feature_name)
    args.alpha = 1

    num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    unlabeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='twice', shuffle=True, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_val_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None, shuffle=False, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes, num_classes))
    labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))
    all_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(num_classes))

    if args.mode == 'train':
        inputsize = [3, 32, 32]
        label_model = VGG_net(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        label_model.load_state_dict(torch.load(args.pretrain_dir))
        for param in label_model.parameters():
            param.requires_grad = False

        # encoder model for unlabeled data
        encoder_model = VGG_net(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        encoder_model = copy.deepcopy(label_model)
        ##
        #init_acc_test, init_nmi_test, init_ari_test, _, _ = init_prob_kmeans(label_model, unlabeled_test_loader, args)
        init_acc, init_nmi, init_ari, init_centers, init_probs = init_prob_kmeans(label_model, unlabeled_val_loader, args)
        args.p_targets = target_distribution(init_probs)
        #encoder_model.center = Parameter(torch.Tensor(args.n_clusters, args.n_pca))
        encoder_model.center.data = torch.tensor(init_centers).float().to(args.device)
        ##
        for param in encoder_model.parameters():
            param.requires_grad = True

        ## Training
        train(label_model, encoder_model, unlabeled_train_loader, unlabeled_val_loader, args)

        ## Save clusters (args.n_clusters*args.n_clusters)
        sio.savemat(args.save_clusters_path, {'clusters': encoder_model.center.data.cpu().numpy()})
        ## Save model
        torch.save(encoder_model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

        ## Test
        ## Test
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only, _ = eval_unlabel_classes(encoder_model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(encoder_model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(encoder_model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(encoder_model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(encoder_model, all_test_loader, args)
        #print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
        print('[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all, ari_label_all))
        print('[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))

        if args.save_txt:
            with open(args.save_txt_path, 'a') as f:
                #f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write("[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
                f.write("[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_only, nmi_label_only, ari_label_only))
                f.write("[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
                f.write("[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_all, nmi_label_all, ari_label_all))
                f.write("[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_test_all, nmi_test_all, ari_test_all))
    else:
        # matcontent = sio.loadmat(args.save_clusters_path)
        # clusters = matcontent['clusters']
        # args.center = torch.from_numpy(clusters).float().to(args.device)
        inputsize = [3, 32, 32]
        encoder_model = VGG_net(inputsize, args.num_labeled_classes, args.num_unlabeled_classes)
        encoder_model = encoder_model.to(args.device).to(args.device)
        ###
        print('Load model ...')
        encoder_model.load_state_dict(torch.load(args.model_dir))
        encoder_model.eval()

        ## weight aligning
        # weight_label = encoder_model.last_label.weight.data
        # bias_label = encoder_model.last_label.bias.data
        # bias_label = torch.unsqueeze(bias_label, 1)
        # w_label = torch.cat((weight_label,bias_label), dim=1)
        # #
        # weight_unlabel = encoder_model.last_unlabel.weight.data
        # bias_unlabel = encoder_model.last_unlabel.bias.data
        # bias_unlabel = torch.unsqueeze(bias_unlabel, 1)
        # w_unlabel = torch.cat((weight_unlabel,bias_unlabel), dim=1)
        # # L2 norm or L1 norm ?
        # w_label = torch.norm(w_label, p=2, dim=1)
        # w_unlabel = torch.norm(w_unlabel, p=2, dim=1)
        # args.ratio = torch.mean(w_label) / torch.mean(w_unlabel)
        #args.alpha = 4
        #acc_val, nmi_val, ari_val, _ = eval_unlabel_classes(encoder_model, unlabeled_test_loader, args)
        #all_acc_test, all_nmi_test, all_ari_test = eval_all_classes(encoder_model, unlabeled_test_loader, args)
        #all_acc_test, all_nmi_test, all_ari_test = eval_all_classes(encoder_model, labeled_test_loader, args)

        #eval_all_classes_refine(encoder_model, all_test_loader, args)
        #extract_feature(encoder_model, unlabeled_test_loader, args)

        eval_unlabel_classes_merge(encoder_model, unlabeled_test_loader, args)

        # centers = encoder_model.center.data
        # centers_norm = func.normalize(centers, p=2, dim=1)
        # sim = torch.matmul(centers_norm, torch.transpose(centers_norm, 0, 1))
        print(100*'-')

