#!/usr/bin/env bash


python cifar100_DTC.py --num_labeled_classes 20
python cifar100_AutoNovel.py --num_labeled_classes 20
python cifar100_ResNovel.py --num_labeled_classes 20

python cifar100_DTC.py --num_labeled_classes 30
python cifar100_AutoNovel.py --num_labeled_classes 30
python cifar100_ResNovel.py --num_labeled_classes 30

python cifar100_DTC.py --num_labeled_classes 40
python cifar100_AutoNovel.py --num_labeled_classes 40
python cifar100_ResNovel.py --num_labeled_classes 40

python cifar100_DTC.py --num_labeled_classes 50
python cifar100_AutoNovel.py --num_labeled_classes 50
python cifar100_ResNovel.py --num_labeled_classes 50

python cifar100_DTC.py --num_labeled_classes 60
python cifar100_AutoNovel.py --num_labeled_classes 60
python cifar100_ResNovel.py --num_labeled_classes 60

python cifar100_DTC.py --num_labeled_classes 70
python cifar100_AutoNovel.py --num_labeled_classes 70
python cifar100_ResNovel.py --num_labeled_classes 70




