import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.optim import SGD, lr_scheduler
from torch.autograd import Variable
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from utils.util import cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.resnet_3x3 import ResNet, BasicBlock, ResNet_unlabel
from modules.module import feat2prob, target_distribution
from data.cifarloader import CIFAR100Loader
from tqdm import tqdm
import numpy as np
import warnings
import random
import os
warnings.filterwarnings("ignore", category=UserWarning)
import scipy.io as sio
import copy

def init_prob_kmeans(model, eval_loader, args):
    torch.manual_seed(1)
    model = model.to(args.device)
    # cluster parameter initiate
    model.eval()
    targets = np.zeros(len(eval_loader.dataset))
    feats = np.zeros((len(eval_loader.dataset), 512))
    for _, (x, label, idx) in enumerate(eval_loader):
        x = x.to(args.device)
        feat = model(x)
        idx = idx.data.cpu().numpy()
        feats[idx, :] = feat.data.cpu().numpy()
        targets[idx] = label.data.cpu().numpy()
    # evaluate clustering performance
    pca = PCA(n_components=args.n_clusters)
    feats = pca.fit_transform(feats)
    kmeans = KMeans(n_clusters=args.n_clusters, n_init=20)
    y_pred = kmeans.fit_predict(feats)
    acc, nmi, ari = cluster_acc(targets, y_pred), nmi_score(targets, y_pred), ari_score(targets, y_pred)
    print('Init acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    probs = feat2prob(torch.from_numpy(feats), torch.from_numpy(kmeans.cluster_centers_))
    return acc, nmi, ari, kmeans.cluster_centers_, probs

def warmup_train(model, train_loader, eva_loader, args):
    optimizer = SGD(model.parameters(), lr=args.warmup_lr, momentum=args.momentum, weight_decay=args.weight_decay)
    for epoch in range(args.warmup_epochs):
        loss_record = AverageMeter()
        model.train()
        for batch_idx, ((x, _), label, idx) in enumerate(tqdm(train_loader)):
            x = x.to(args.device)
            _, feat = model(x, flag=1)
            prob = feat2prob(feat, model.center)
            loss = F.kl_div(prob.log(), args.p_targets[idx].float().to(args.device))
            loss_record.update(loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Warmup_train Epoch: {} Avg Loss: {:.4f}'.format(epoch, loss_record.avg))
        _, _, _, probs = eval_unlabel_classes(model, eva_loader, args)
    args.p_targets = target_distribution(probs)


def PI_train(model, train_loader, eva_loader, args):
    optimizer = SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    w = 0
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        model.train()
        exp_lr_scheduler.step()
        w = args.rampup_coefficient * ramps.sigmoid_rampup(epoch, args.rampup_length)
        for batch_idx, ((x, x_bar), label, idx) in enumerate(tqdm(train_loader)):
            x, x_bar = x.to(args.device), x_bar.to(args.device)
            _, feat = model(x, flag=1)
            _, feat_bar = model(x_bar, flag=1)
            prob = feat2prob(feat, model.center)
            prob_bar = feat2prob(feat_bar, model.center)
            sharp_loss = F.kl_div(prob.log(), args.p_targets[idx].float().to(args.device))
            consistency_loss = F.mse_loss(prob, prob_bar)
            loss = sharp_loss + w * consistency_loss
            loss_record.update(loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {} Avg Loss: {:.4f}'.format(epoch, loss_record.avg))
        _, _, _, probs = eval_unlabel_classes(model, eva_loader, args)
        if (epoch+1) % args.update_interval ==0:
            print('updating target ...')
            args.p_targets = target_distribution(probs)
        if epoch % 20 == 0:
            torch.save(model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))

def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            #out = model(x, head=1)
            _, _, out_unlabel = model(x, flag=2)
            prob_pca = feat2prob(out_unlabel, model.center)
            _, pred_pca = prob_pca.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            idx = idx.data.cpu().numpy()
            #feats[idx, :] = feat.cpu().detach().numpy()
            probs_pca[idx, :] = prob_pca.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[Unlabel Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
        probs_pca = torch.from_numpy(probs_pca)

    return acc, nmi, ari, probs_pca

def eval_label_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, _ = model(x, flag=2)
            _, pred_pca = out_label.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            #feats[idx, :] = feat.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[Label Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))

    return acc, nmi, ari

def eval_all_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, out_unlabel = model(x, flag=2)
            out_unlabel = feat2prob(out_unlabel, model.center)
            out_cat = torch.cat([out_label, out_unlabel], dim=1)
            _, pred_pca = out_cat.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            #feats[idx, :] = feat.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[Label Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))

    return acc, nmi, ari

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
            description='cluster',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--warmup_flag', default=False, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--warmup_lr', type=float, default=0.1)
    parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--warmup_epochs', default=30, type=int)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=5, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    parser.add_argument('--milestones', default=[40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--update_interval', default=30, type=int)
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--num_labeled_classes', default=80, type=int)
    parser.add_argument('--n_clusters', default=20, type=int)
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--pretrain_dir', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/experiments/pretrained/resnet18_new_LR_cifar100_classif')
    parser.add_argument('--dataset_root', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/datasets/CIFAR/')
    parser.add_argument('--exp_root', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/experiments/')
    parser.add_argument('--model_name', type=str, default='resnet18_cifar100_DTC')
    #parser.add_argument('--test_model_dir', type=str, default='/esat/realgar/yliu/Codes/DTC-master/data/experiments/cifar10_DTC/PI/PI_run_1.pth')
    parser.add_argument('--save_txt_name', type=str, default='Result_resnet18_cifar100_DTC')
    parser.add_argument('--DTC', type=str, default='PI')
    parser.add_argument('--mode', type=str, default='test')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir= args.exp_root + '{}/{}'.format(runner_name, args.DTC)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir+'/'+args.model_name+'_label_{}_unlabel_{}.pth'.format(args.num_labeled_classes, args.num_unlabeled_classes)
    args.save_txt_path= args.exp_root+ '{}/{}/{}'.format(runner_name, args.DTC, args.save_txt_name) + '_label_{}_unlabel_{}.txt'.format(args.num_labeled_classes, args.num_unlabeled_classes)
    args.pretrain_dir = args.pretrain_dir + '_{}.pth'.format(args.num_labeled_classes)

    # num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    # unlabeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='twice', shuffle=True, target_list = range(args.num_labeled_classes, num_classes))
    # unlabeled_val_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None, shuffle=False, target_list = range(args.num_labeled_classes, num_classes))
    # unlabeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes, num_classes))
    # labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))
    # all_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(num_classes))

    #num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    unlabeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='twice', shuffle=True, target_list = range(80, 100))
    unlabeled_val_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None, shuffle=False, target_list = range(80, 100))
    unlabeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(80, 100))
    labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))
    #all_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(num_classes))

    if args.mode == 'train':
        model = ResNet(BasicBlock, [2, 2, 2, 2], args.num_labeled_classes).to(args.device)
        model.load_state_dict(torch.load(args.pretrain_dir), strict=False)
        model.linear= Identity()
        init_feat_extractor = model
        init_acc, init_nmi, init_ari, init_centers, init_probs = init_prob_kmeans(init_feat_extractor, unlabeled_val_loader, args)
        args.p_targets = target_distribution(init_probs)

        model = ResNet_unlabel(BasicBlock, [2, 2, 2, 2], nclass_label=args.num_labeled_classes,nclass_unlabel=args.num_unlabeled_classes).to(args.device)
        model.load_state_dict(torch.load(args.pretrain_dir), strict=False)
        #model.center= Parameter(torch.Tensor(args.n_clusters, args.n_clusters))
        model.center.data = torch.tensor(init_centers).float().to(args.device)

        for param in model.parameters():
            param.requires_grad = True

        if args.warmup_flag:
            warmup_train(model, unlabeled_train_loader, unlabeled_val_loader, args)

        PI_train(model, unlabeled_train_loader, unlabeled_val_loader, args)

        ## save
        #sio.savemat(args.save_clusters_path, {'clusters': model.center.data.cpu().numpy()})
        ## Save model
        torch.save(model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

        ## Test
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only, _ = eval_unlabel_classes(model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(model, labeled_test_loader, args)
        #acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(model, all_test_loader, args)
        print('[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
        print('[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all, ari_label_all))
        #print('[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))

        if 1==1:
            with open(args.save_txt_path, 'a') as f:
                #f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write("[Unlabel Test only] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
                f.write("[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_only, nmi_label_only, ari_label_only))
                f.write("[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
                f.write("[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_all, nmi_label_all, ari_label_all))
                #f.write("[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_test_all, nmi_test_all, ari_test_all))
    else:
        model = ResNet_unlabel(BasicBlock, [2, 2, 2, 2], nclass_label=args.num_labeled_classes,nclass_unlabel=args.num_unlabeled_classes).to(args.device)
        ###
        print('Load model ...')
        model.load_state_dict(torch.load(args.model_dir))
        model.eval()
        ##
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only, _ = eval_unlabel_classes(model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(model, all_test_loader, args)
        # #print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel Test only] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[Unlabel Test split] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
        print('[Label Test split] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all, ari_label_all))
        print('[ALL Test split] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))