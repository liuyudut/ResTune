import numpy as np
import matplotlib.pyplot as plt


##### Hyper-parameter #####
# plt.figure(1) # the first figure
# plt.subplot(121) # the first subplot in the first figure
#
# # example data
# x = [1, 2, 3, 4, 5]
# cifar10 = [47.9, 51, 52.1, 52.1, 51.5]
# cifar100 = [54.51, 58.5, 59.1, 58.6, 58.2]
# tinyimagenet = [38.2, 41.2, 41.2, 40.8, 40]
#
# plt.plot(x, cifar10, label="CIFAR-10", marker='o')
# plt.plot(x, cifar100, label="CIFAR-100", marker='D')
# plt.plot(x, tinyimagenet, label="Tiny-ImageNet", marker='s')
# plt.xticks(x, ('0', '0.1', '0.5', '1', '2'))
# plt.ylabel('All Classes Accuracy ($Acc^A$)')
#
# plt.subplot(122) # the second subplot in the first figure
#
# # example data
# x = [1, 2, 3, 4, 5]
# cifar10 = [51, 51.5, 52.1, 52, 50]
# cifar100 = [58.5, 59, 59.1, 58, 57]
# tinyimagenet = [40.6, 41, 41.2, 41.4, 40.3]
#
# plt.plot(x, cifar10, label="CIFAR-10", marker='o')
# plt.plot(x, cifar100, label="CIFAR-100", marker='D')
# plt.plot(x, tinyimagenet, label="Tiny-ImageNet", marker='s')
# plt.xticks(x, ('1', '5', '10', '15', '20'))
# plt.xlabel('top-$k$')
# plt.ylabel('All Classes Accuracy ($Acc^A$)')
#
# plt.show()

##### Fewer labeled classes #####
plt.figure(1) # the first figure
plt.subplot(121) # the first subplot in the first figure

# example data
x = [1, 2, 3, 4, 5, 6, 7]
DTC_unlabel = [62.5, 57.8, 54.7, 52.9, 52.3, 43.7, 42.05]
AutoNovel_unlabel = [60, 52.15, 47.85, 50.9, 47.05, 37.25, 38.8]
ResTune_unlabel = [63.7, 60, 55.7, 54.6, 54.85, 45.9, 45.1]

plt.plot(x, DTC_unlabel, label="DTC", color='darkgreen', marker='o')
plt.plot(x, AutoNovel_unlabel, label="AutoNovel", color='darkorange', marker='D')
plt.plot(x, ResTune_unlabel, label="ResTune", color='darkred', marker='s')
plt.xticks(x, ('80', '70', '60', '50', '40', '30', '20'))
plt.xlabel('Number of labeled classes ($C^l$)')
plt.ylabel('Unlabeled Classes Accuracy ($Acc^U$)')

plt.subplot(122) # the second subplot in the first figure

# example data
x = [1, 2, 3, 4, 5, 6, 7]
DTC_label = [62.12, 58.56, 54.07, 56.7, 58.85, 64.9, 66.5]
AutoNovel_label = [70.67, 67.2, 68.6, 73.06, 72.85, 72.4, 73.73]
ResTune_label = [73.8, 69.1, 70.6, 75.74, 77.65, 75.3, 77.15]

plt.plot(x, DTC_label, label="DTC", color='darkgreen', marker='o')
plt.plot(x, AutoNovel_label, label="AutoNovel", color='darkorange', marker='D')
plt.plot(x, ResTune_label, label="ResTune", color='darkred', marker='s')
plt.xticks(x, ('80', '70', '60', '50', '40', '30', '20'))
plt.xlabel('Number of labeled classes ($C^l$)')
plt.ylabel('Labeled Classes Accuracy ($Acc^L$)')

plt.show()