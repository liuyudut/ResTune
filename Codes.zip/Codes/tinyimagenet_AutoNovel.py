import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import SGD, lr_scheduler
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from utils.util import BCE_AutoNovel, PairEnum, cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.resnet_3x3 import ResNet, BasicBlock, ResNet_unlabel
from data.tinyimagenet_loader import TinyImageNetLoader
from tqdm import tqdm
import numpy as np
import os


def train(model, train_loader, unlabeled_eval_loader, labeled_test_loader, args):
    optimizer = SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    criterion1 = nn.CrossEntropyLoss()
    criterion2 = BCE_AutoNovel()
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        model.train()
        exp_lr_scheduler.step()
        w = args.rampup_coefficient * ramps.sigmoid_rampup(epoch, args.rampup_length)
        for batch_idx, (x, label) in enumerate(tqdm(train_loader)):
            x, label = x.to(device), label.to(device)
            feat, out_label, out_unlabel = model(x, flag=2)
            feat_bar, out_label_bar, out_unlabel_bar = model(x, flag=2)
            prob2, prob2_bar = F.softmax(out_unlabel, dim=1), F.softmax(out_unlabel_bar, dim=1)

            mask_lb = label < args.num_labeled_classes

            rank_feat = (feat[~mask_lb]).detach()
            rank_idx = torch.argsort(rank_feat, dim=1, descending=True)
            rank_idx1, rank_idx2 = PairEnum(rank_idx)
            rank_idx1, rank_idx2 = rank_idx1[:, :args.topk], rank_idx2[:, :args.topk]
            rank_idx1, _ = torch.sort(rank_idx1, dim=1)
            rank_idx2, _ = torch.sort(rank_idx2, dim=1)

            rank_diff = rank_idx1 - rank_idx2
            rank_diff = torch.sum(torch.abs(rank_diff), dim=1)
            target_ulb = torch.ones_like(rank_diff).float().to(device)
            target_ulb[rank_diff > 0] = -1

            prob1_ulb, _ = PairEnum(prob2[~mask_lb])
            _, prob2_ulb = PairEnum(prob2_bar[~mask_lb])

            # loss_ce = criterion1(output1[mask_lb], label[mask_lb])
            loss_bce = criterion2(prob1_ulb, prob2_ulb, target_ulb)
            consistency_loss = F.mse_loss(prob2, prob2_bar)  # F.mse_loss(prob1, prob1_bar) +
            loss = loss_bce + w * consistency_loss

            loss_record.update(loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {} Avg Loss: {:.4f}'.format(epoch, loss_record.avg))
        eval_unlabel_classes(model, unlabeled_eval_loader, args)
        eval_label_classes(model, labeled_test_loader, args)
        if epoch % 20 == 0:
            torch.save(model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))

def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    for batch_idx, (x, label) in enumerate(tqdm(test_loader)):
        x, label = x.to(device), label.to(device)
        _, _, out_unlabel = model(x, flag=2)
        _, pred = out_unlabel.max(1)
        targets = np.append(targets, label.cpu().numpy())
        preds = np.append(preds, pred.cpu().numpy())
    acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                              preds)
    print('[Unlabeled classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari


def eval_label_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    for batch_idx, (x, label) in enumerate(tqdm(test_loader)):
        x, label = x.to(device), label.to(device)
        _, out_label, _ = model(x, flag=2)
        _, pred = out_label.max(1)
        targets = np.append(targets, label.cpu().numpy())
        preds = np.append(preds, pred.cpu().numpy())
    acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                              preds)
    print('[Labeled classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari


def eval_all_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    for batch_idx, (x, label) in enumerate(tqdm(test_loader)):
        x, label = x.to(device), label.to(device)
        _, out_label, out_unlabel = model(x, flag=2)
        out_concat = torch.cat([out_label, out_unlabel], 1)
        _, pred = out_concat.max(1)
        targets = np.append(targets, label.cpu().numpy())
        preds = np.append(preds, pred.cpu().numpy())
    acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                              preds)
    print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='cluster',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-5)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=5, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    # parser.add_argument('--increment_coefficient', type=float, default=0.05)
    parser.add_argument('--milestones', default=[40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--num_labeled_classes', default=180, type=int)
    parser.add_argument('--dataset_root', type=str, default='/esat/realgar/yliu/Datasets/tiny-imagenet-200/')
    parser.add_argument('--exp_root', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/experiments/')
    parser.add_argument('--pretrain_dir', type=str,
                        default='/esat/realgar/yliu/Codes/object_discovery/data/experiments/pretrained/resnet18_tinyimagenet_classif_180.pth')
    parser.add_argument('--topk', default=5, type=int)
    parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    # parser.add_argument('--IL', action='store_true', default=False, help='w/ incremental learning')
    parser.add_argument('--model_name', type=str, default='resnet18_tinyimagenet_AutoNovel_label_180_unlabel_20')
    parser.add_argument('--dataset_name', type=str, default='cifar100', help='options: cifar10, cifar100, svhn')
    parser.add_argument('--save_txt_name', type=str,
                        default='Results_resnet18_tinyimagenet_AutoNovel_label_180_unlabel_20.txt')
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--mode', type=str, default='test')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir = os.path.join(args.exp_root, runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir + '/' + '{}.pth'.format(args.model_name)
    args.save_txt_path = model_dir + '/' + '{}.pth'.format(args.save_txt_name)

    num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    unlabeled_train_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='once', shuffle=False, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_val_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None, shuffle=False, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_test_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='val_folders', aug=None, shuffle=False, target_list=range(args.num_labeled_classes, num_classes))
    labeled_test_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='val_folders', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))
    all_test_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='val_folders', aug=None, shuffle=False, target_list=range(num_classes))


    if args.mode == 'train':
        model = ResNet_unlabel(BasicBlock, [2, 2, 2, 2], nclass_label=args.num_labeled_classes,nclass_unlabel=args.num_unlabeled_classes).to(args.device)
        model.load_state_dict(torch.load(args.pretrain_dir), strict=False)
        ## Freeze bottom layers and fine-tune only top layers
        for param in model.parameters():
            param.requires_grad = True
        for name, param in model.named_parameters():
            if 'linear' not in name and 'layer4' not in name:
                param.requires_grad = False

        ## without joint training of labelled and unlabelled data
        train(model, unlabeled_train_loader, unlabeled_val_loader, labeled_test_loader, args)
        torch.save(model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

        ##
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only = eval_unlabel_classes(model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(model, all_test_loader, args)
        # print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print(
            '[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only,
                                                                                     ari_unlabel_only))
        print('[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only,
                                                                                     ari_label_only))
        print(
            '[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all,
                                                                                      ari_unlabel_all))
        print('[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all,
                                                                                      ari_label_all))
        print('[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all,
                                                                                    ari_test_all))

        if 1==1:
            with open(args.save_txt_path, 'a') as f:
                # f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write("[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_only,
                                                                                                   nmi_unlabel_only,
                                                                                                   ari_unlabel_only))
                f.write("[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_only,
                                                                                                 nmi_label_only,
                                                                                                 ari_label_only))
                f.write("[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_all,
                                                                                                    nmi_unlabel_all,
                                                                                                    ari_unlabel_all))
                f.write("[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_all,
                                                                                                  nmi_label_all,
                                                                                                  ari_label_all))
                f.write(
                    "[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_test_all, nmi_test_all,
                                                                                            ari_test_all))
    else:
        model = ResNet_unlabel(BasicBlock, [2, 2, 2, 2], nclass_label=args.num_labeled_classes,nclass_unlabel=args.num_unlabeled_classes).to(args.device)
        ###
        print('Load model ...')
        model.load_state_dict(torch.load(args.model_dir))
        model.eval()
        ##
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only = eval_unlabel_classes(model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(model, all_test_loader, args)
        # #print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel Test only] AutoNovel: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] AutoNovel: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[Unlabel Test split] AutoNovel: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
        print('[Label Test split] AutoNovel: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all, ari_label_all))
        print('[ALL Test split] AutoNovel: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))

