import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.optim import SGD, lr_scheduler
from torch.autograd import Variable
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from utils.util import BCE, PairEnum, cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.vgg_RCL import VGG_encoder, VGG_decoder
from modules.module import feat2prob, target_distribution
from data.cifarloader import CIFAR100Loader
from tqdm import tqdm
import numpy as np
import warnings
import os
import scipy.io as sio
import copy
from copy import deepcopy
import torch.nn.functional as func

#warnings.filterwarnings("ignore", category=UserWarning)

def compute_sim_loss(feat_old, feat_new, sim_criterion, args):
    feat_old = func.normalize(feat_old, p=2, dim=1)
    feat_new = func.normalize(feat_new, p=2, dim=1)
    one_batch = torch.ones(feat_new.size(0)).to(args.device)
    sim_loss = sim_criterion(feat_old, feat_new, one_batch)

    return sim_loss

def compute_diff_loss(D1, D2, args):
    D1=D1.view(D1.size(0), -1)
    D1_norm=torch.norm(D1, p=2, dim=1, keepdim=True).detach()
    D1_norm=D1.div(D1_norm.expand_as(D1) + 1e-6)

    D2=D2.view(D2.size(0), -1)
    D2_norm=torch.norm(D2, p=2, dim=1, keepdim=True).detach()
    D2_norm=D2.div(D2_norm.expand_as(D2) + 1e-6)

    # return torch.mean((D1_norm.mm(D2_norm.t()).pow(2)))
    return torch.mean((D1_norm.mm(D2_norm.t()).pow(2)))

def guassian_kernel(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    n_samples = int(source.size()[0]) + int(target.size()[0])
    total = torch.cat([source, target], dim=0)

    total0 = total.unsqueeze(0).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
    total1 = total.unsqueeze(1).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
    L2_distance = ((total0 - total1) ** 2).sum(2)
    if fix_sigma:
        bandwidth = fix_sigma
    else:
        bandwidth = torch.sum(L2_distance.data) / (n_samples ** 2 - n_samples)
    bandwidth /= kernel_mul ** (kernel_num // 2)
    bandwidth_list = [bandwidth * (kernel_mul ** i) for i in range(kernel_num)]
    kernel_val = [torch.exp(-L2_distance / bandwidth_temp) for bandwidth_temp in bandwidth_list]
    return sum(kernel_val)

def compute_MMD_loss(source, target, args):
    batch_size = int(source.size()[0])
    kernels = guassian_kernel(source, target)
    XX = kernels[:batch_size, :batch_size]
    YY = kernels[batch_size:, batch_size:]
    XY = kernels[:batch_size, batch_size:]
    YX = kernels[batch_size:, :batch_size]
    loss = torch.mean(XX + YY - XY - YX)

    return loss

def train(old_model, encoder_model, decoder_model, train_loader, eva_loader, args):
    params = list(encoder_model.parameters()) + list(decoder_model.parameters())
    optimizer = SGD(params, lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    #criterion1 = nn.CrossEntropyLoss()
    bce_criterion = BCE().to(args.device)
    mse_criterion = torch.nn.MSELoss().to(args.device)
    for epoch in range(args.epochs):
        total_loss_record = AverageMeter()
        cluster_loss_record = AverageMeter()
        diff_loss_record = AverageMeter()
        reconst_loss_record = AverageMeter()
        reg_loss_record = AverageMeter()
        encoder_model.train()
        decoder_model.train()
        old_model.eval()
        exp_lr_scheduler.step()
        #w = args.rampup_coefficient * ramps.sigmoid_rampup(epoch, args.rampup_length)
        for batch_idx, ((x, _), label, idx) in enumerate(tqdm(train_loader)):
            x, label = x.to(args.device), label.to(args.device)
            feat_label, feat_unlabel, out_label, out_unlabel = encoder_model(x, flag=1)
            prob = F.softmax(out_unlabel, dim=1)
            #mask_lb = label < args.num_labeled_classes
            ## ranking loss
            feat_sum = feat_label + feat_unlabel
            feat_copy = feat_sum.detach()
            feat_copy = func.normalize(feat_copy, p=2, dim=1)
            rank_feat = feat_copy.mm(feat_copy.t())

            rank_idx = torch.argsort(rank_feat, dim=1, descending=True)
            rank_idx1, rank_idx2 = PairEnum(rank_idx)
            rank_idx1, rank_idx2 = rank_idx1[:, :args.topk], rank_idx2[:, :args.topk]
            rank_idx1, _ = torch.sort(rank_idx1, dim=1)
            rank_idx2, _ = torch.sort(rank_idx2, dim=1)

            rank_diff = rank_idx1 - rank_idx2
            rank_diff = torch.sum(torch.abs(rank_diff), dim=1)
            target_ulb = torch.ones_like(rank_diff).float().to(args.device)
            target_ulb[rank_diff > 0] = -1

            prob1_ulb, prob2_ulb = PairEnum(prob)
            cluster_loss = bce_criterion(prob1_ulb, prob2_ulb, target_ulb)

            ## difference loss
            diff_loss = compute_diff_loss(feat_label, feat_unlabel, args)

            # LwF loss
            _, ref_output = old_model(x, flag=0)
            soft_target = F.softmax(ref_output / 2, dim=1)
            new_output = old_model.last_label(feat_label)
            logp = F.log_softmax(new_output / 2, dim=1)
            reg_loss = -torch.mean(torch.sum(soft_target * logp, dim=1))  # * args.T * args.T

            ## reconstruct loss
            feat_sum = feat_label + feat_unlabel
            x_rec = decoder_model(feat_sum)
            reconst_loss = mse_criterion(x, x_rec)

            ## total loss
            loss = cluster_loss + diff_loss + reg_loss

            total_loss_record.update(loss.item(), x.size(0))
            cluster_loss_record.update(cluster_loss.item(), x.size(0))
            diff_loss_record.update(diff_loss.item(), x.size(0))
            reconst_loss_record.update(reconst_loss.item(), x.size(0))
            reg_loss_record.update(reg_loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {}, cluster Loss: {:.4f}, reg Loss: {:.4f}, diff Loss: {:.4f}, reconst Loss: {:.4f}'.format(epoch,
                cluster_loss_record.avg, reg_loss_record.avg, diff_loss_record.avg, reconst_loss_record.avg))
        _, _, _ = eval_unlabel_classes(encoder_model, eva_loader, args)
        if epoch%50==0:
            torch.save(encoder_model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))

def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, _, _, out_unlabel = model(x, flag=1)
            prob = F.softmax(out_unlabel, dim=1)
            _, pred = prob.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds = np.append(preds, pred.cpu().numpy())

        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                                  preds)
        print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_label_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, _, out_label, _ = model(x, flag=1)
            prob = F.softmax(out_label, dim=1)
            _, pred = prob.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds = np.append(preds, pred.cpu().numpy())

        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                                  preds)
        print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_all_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, _, out_label, out_unlabel = model(x, flag=1)
            out = torch.cat((out_label, out_unlabel), 1)
            prob = F.softmax(out, dim=1)
            _, pred = prob.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds = np.append(preds, pred.cpu().numpy())

        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                                  preds)
        print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='cluster',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--warmup_flag', default=False, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--warmup_lr', type=float, default=0.05)
    parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--warmup_epochs', default=30, type=int)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=5, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    parser.add_argument('--milestones', default=[20, 40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--update_interval', default=50, type=int) ## may be important?
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--num_labeled_classes', default=80, type=int)
    parser.add_argument('--n_clusters', default=20, type=int)
    parser.add_argument('--topk', default=5, type=int)
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    #parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/cifar100_classif_New/cifar100_vgg4+2_label_80.pth')
    parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/cifar100_classif/vgg4+2_cifar100_RCL_label_80.pth')
    parser.add_argument('--dataset_root', type=str, default='./data/datasets/CIFAR/')
    parser.add_argument('--exp_root', type=str, default='./data/experiments/')
    parser.add_argument('--model_name', type=str, default='vgg4+2_cifar100_AutoNovel_label_80_unlabel_20.pth')
    parser.add_argument('--save_txt_name', type=str, default='AutoNovel_results_vgg4+2_cifar100_RCL_label_80_unlabel_20.txt')
    parser.add_argument('--save_clusters_name', type=str, default='clusters_vgg4+2_cifar100_AutoNovel_label_80_unlabel_20.mat')
    parser.add_argument('--mode', type=str, default='train')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir = args.exp_root + '{}'.format(runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir + '/' + args.model_name
    args.save_txt_path = args.exp_root + '{}/{}'.format(runner_name, args.save_txt_name)
    args.save_clusters_path = args.exp_root + '{}/{}'.format(runner_name, args.save_clusters_name)

    num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    unlabeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='twice', shuffle=True, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_val_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None, shuffle=False, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes, num_classes))
    labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))
    all_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(num_classes))

    if args.mode == 'train':
        inputsize = [3, 32, 32]
        label_model = VGG_encoder(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        label_model.load_state_dict(torch.load(args.pretrain_dir))
        for param in label_model.parameters():
            param.requires_grad = False

        # encoder model for unlabeled data
        encoder_model = VGG_encoder(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        encoder_model = copy.deepcopy(label_model)
        for param in encoder_model.parameters():
            param.requires_grad = True
        ## decoder model for unlabeled data
        decoder_model = VGG_decoder(inputsize).to(args.device)
        for param in decoder_model.parameters():
            param.requires_grad = True

        train(label_model, encoder_model, decoder_model, unlabeled_train_loader, unlabeled_val_loader, args)
        torch.save(encoder_model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

        ## Test
        acc_val, nmi_val, ari_val = eval_unlabel_classes(encoder_model, unlabeled_test_loader, args)
        unlabel_acc_test, unlabel_nmi_test, unlabel_ari_test = eval_all_classes(encoder_model, unlabeled_test_loader, args)
        label_acc_test, label_nmi_test, label_ari_test = eval_all_classes(encoder_model, labeled_test_loader, args)
        all_acc_test, all_nmi_test, all_ari_test = eval_all_classes(encoder_model, all_test_loader, args)
        # print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_val, nmi_val, ari_val))
        # print('[Test split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc_test, init_nmi_test, init_ari_test))
        print('[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(unlabel_acc_test, unlabel_nmi_test,
                                                                                        unlabel_ari_test))
        print('[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(label_acc_test, label_nmi_test,
                                                                                      label_ari_test))
        print('[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(all_acc_test, all_nmi_test,
                                                                                    all_ari_test))

        if args.save_txt:
            with open(args.save_txt_path, 'a') as f:
                # f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write(
                    "[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_val, nmi_val, ari_val))
                # f.write("[Test split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc_test, init_nmi_test, init_ari_test))
                f.write("[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(unlabel_acc_test,
                                                                                                    unlabel_nmi_test,
                                                                                                    unlabel_ari_test))
                f.write("[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(label_acc_test,
                                                                                                  label_nmi_test,
                                                                                                  label_ari_test))
                f.write(
                    "[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(all_acc_test, all_nmi_test,
                                                                                           all_ari_test))
    else:
        matcontent = sio.loadmat(args.save_clusters_path)
        clusters = matcontent['clusters']
        args.center = torch.from_numpy(clusters).float().to(args.device)
        inputsize = [3, 32, 32]
        model = VGG_unlabel(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        ###
        print('Load model ...')
        model.load_state_dict(torch.load(args.model_dir))
        eval_unlabel_classes(model, unlabeled_test_loader, args)
