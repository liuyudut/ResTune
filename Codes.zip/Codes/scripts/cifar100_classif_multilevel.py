import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import SGD, lr_scheduler
from utils.util import AverageMeter, accuracy, seed_torch
from data.cifarloader import CIFAR100Loader
#from models.vgg import VGG
from models.vgg_RCL_Multilevel import VGG_encoder
import os
import numpy as np
import sys,time
# def get_optimizer(model, lr):
#     return torch.optim.SGD(model.parameters(), lr=lr)

def train(model, train_loader, eval_loader, args):
    #lr = args.lr
    #patience = args.lr_patience
    optimizer = SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    #optimizer = SGD(model.parameters(), lr=args.lr)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    criterion=nn.CrossEntropyLoss().cuda(args.device)
    #best_loss = np.inf
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        #acc_record = AverageMeter()
        model.train()
        exp_lr_scheduler.step()
        for batch_idx, (x, label, _) in enumerate(train_loader):
            x, target = x.to(args.device), label.to(args.device)
            optimizer.zero_grad()
            _, output= model(x, flag=0)
            loss = criterion(output, target)
            #acc = accuracy(output, target)
            loss.backward()
            optimizer.step()
            #acc_record.update(acc[0].item(), x.size(0))
            loss_record.update(loss.item(), x.size(0))
        print('Train Epoch: {} Avg Loss: {:.4f}'.format(epoch, loss_record.avg))
        eval(model, eval_loader, args)

        if epoch%50==0:
            torch.save(model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))

    torch.save(model.state_dict(), args.model_dir)
    print("model saved to {}.".format(args.model_dir))


def eval(model, test_loader, args):
    model.eval()
    acc0_record = AverageMeter()
    for batch_idx, (x, label, _) in enumerate(test_loader):
        x, target = x.to(args.device), label.to(args.device)
        _, output = model(x)
        acc0 = accuracy(output, target)
        acc0_record.update(acc0[0].item(), x.size(0))
    print('Test: Avg Acc: {:.4f}'.format(acc0_record.avg))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
            description='cls',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--lr', type=float, default=0.05)
    #parser.add_argument('--lr_min', type=float, default=1e-4)
    #parser.add_argument('--lr_factor', type=int, default=3)
    #parser.add_argument('--lr_patience', type=int, default=5)
    #parser.add_argument('--clipgrad', type=int, default=10000)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--milestones', default=[20, 40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--num_labeled_classes', default=80, type=int)
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--model_name', type=str, default='vgg4+2_cifar100_RCL_multilevel_label')
    parser.add_argument('--dataset_root', type=str, default='./data/datasets/CIFAR/')
    parser.add_argument('--exp_root', type=str, default='./data/experiments/')
    parser.add_argument('--seed', default=1, type=int)
    #parser.add_argument('--pc_valid', default=0.1, type=float, help='size of validation set')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = 'cifar100_label_pretrain' #os.path.basename(__file__).split(".")[0]
    model_dir= args.exp_root + '{}'.format(runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir+'/'+args.model_name+'_{}.pth'.format(args.num_labeled_classes)

    labeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='once', shuffle=True, target_list=range(args.num_labeled_classes))
    labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))

    inputsize = [3, 32, 32]
    model = VGG_encoder(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
    train(model, labeled_train_loader, labeled_test_loader, args)
    eval(model, labeled_test_loader, args)




