import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import SGD, lr_scheduler
from utils.util import AverageMeter, accuracy, seed_torch
from data.cifarloader import CIFAR100Loader
from models.vggnet_RCL import VGG
import os
import numpy as np
import sys,time
# def get_optimizer(model, lr):
#     return torch.optim.SGD(model.parameters(), lr=lr)

def sub_net_freeze(model, t):
    for n, p in model.layer1[t].named_parameters():
        p.requires_grad = False
    for n, p in model.layer2[t].named_parameters():
        p.requires_grad = False
    for n, p in model.layer3[t].named_parameters():
        p.requires_grad = False
    for n, p in model.layer4[t].named_parameters():
        p.requires_grad = False
    for n, p in model.fc[t].named_parameters():
        p.requires_grad = False
    for n, p in model.last[t].named_parameters():
        p.requires_grad = False


def sub_net_train(model, t):
    for n, p in model.layer1[t].named_parameters():
        p.requires_grad = True
    for n, p in model.layer2[t].named_parameters():
        p.requires_grad = True
    for n, p in model.layer3[t].named_parameters():
        p.requires_grad = True
    for n, p in model.layer4[t].named_parameters():
        p.requires_grad = True
    for n, p in model.fc[t].named_parameters():
        p.requires_grad = True
    for n, p in model.last[t].named_parameters():
        p.requires_grad = True


def train(model, train_loader, eval_loader, args):
    ## freeze previous sub nets
    t = args.step
    if t > 0:
        for i in range(t):
            sub_net_freeze(model, i)
    ## train the new sub net
    sub_net_train(model, t)

    #lr = args.lr
    #patience = args.lr_patience
    optimizer = SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    #optimizer = SGD(model.parameters(), lr=args.lr)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    criterion=nn.CrossEntropyLoss().cuda(device)
    #best_loss = np.inf
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        acc_record = AverageMeter()
        model.train() ##
        exp_lr_scheduler.step()
        for batch_idx, (x, label, _) in enumerate(train_loader):
            x, target = x.to(device), label.to(device)
            optimizer.zero_grad()
            outputs = model(t, x)
            output = outputs[t]
            loss = criterion(output, target)
            acc = accuracy(output, target)
            loss.backward()
            optimizer.step()
            acc_record.update(acc[0].item(), x.size(0))
            loss_record.update(loss.item(), x.size(0))
        print('Train Epoch: {} Avg Loss: {:.4f} \t Avg Acc: {:.4f}'.format(epoch, loss_record.avg, acc_record.avg))
        eval(model, eval_loader, args)

        # if epoch%50==0:
        #     torch.save(model.state_dict(), args.model_dir)
        #     print("model saved to {}.".format(args.model_dir))

    torch.save(model.state_dict(), args.model_dir)
    print("model saved to {}.".format(args.model_dir))


def eval(model, test_loader, args):
    t = args.step
    model.eval()
    acc_record = AverageMeter()
    with torch.no_grad():
        for batch_idx, (x, label, _) in enumerate(test_loader):
            x, target = x.to(device), label.to(device)
            outputs = model(t, x)
            output = outputs[t]
            acc = accuracy(output, target)
            acc_record.update(acc[0].item(), x.size(0))
    print('Test: Avg Acc: {:.4f}'.format(acc_record.avg))

def eval_multi_head(head, model, test_loader, args):
    t = args.step
    model.eval()
    total_num = 0
    total_acc = 0
    with torch.no_grad():
        for batch_idx, (x, label, _) in enumerate(test_loader):
            x, target = x.to(device), label.to(device)
            outputs = model(t, x)
            output = outputs[head]
            _, pred = output.max(1)
            hits = (pred == target).float()
            total_acc += hits.sum().item()  # [0] #hits.sum().data.cpu().numpy()[0]
            total_num += target.size(0)
    print('Test: Avg Acc: {:.4f}'.format(total_acc/total_num))

def eval_single_head(model, test_loader, args):
    t = args.step
    model.eval()
    total_num = 0
    total_acc = 0
    with torch.no_grad():
        for batch_idx, (x, label, _) in enumerate(test_loader):
            x, target = x.to(device), label.to(device)
            outputs = model(t, x)
            output_cat = torch.zeros(target.size(0), (args.step+1)*args.nb_cl).to(device)
            for head in range(args.step+1):
                output_cat[:, head*args.nb_cl:(head+1)*args.nb_cl] = outputs[head]
            ##
            _, pred = output_cat.max(1)
            hits = (pred == target).float()
            total_acc += hits.sum().item()  # [0] #hits.sum().data.cpu().numpy()[0]
            total_num += target.size(0)
    print('Test: Avg Acc: {:.4f}'.format(total_acc/total_num))

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
            description='cls',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--lr', type=float, default=0.05)
    #parser.add_argument('--lr_min', type=float, default=1e-4)
    #parser.add_argument('--lr_factor', type=int, default=3)
    #parser.add_argument('--lr_patience', type=int, default=5)
    #parser.add_argument('--clipgrad', type=int, default=10000)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--milestones', default=[20, 40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--num_labeled_classes', default=20, type=int)
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--model_name', type=str, default='vgg4+2_cifar100_incremental_step')
    parser.add_argument('--old_model_name', type=str, default='vgg4+2_cifar100_incremental_step')
    parser.add_argument('--dataset_root', type=str, default='/esat/realgar/yliu/Datasets/CIFAR/')
    parser.add_argument('--exp_root', type=str, default='./data/experiments/')
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--step', default=1, type=int)
    parser.add_argument('--nb_cl', default=20, type=int)
    parser.add_argument('--mode', default='test', type=str)
    #parser.add_argument('--pc_valid', default=0.1, type=float, help='size of validation set')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir= args.exp_root + '{}'.format(runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir+'/'+args.model_name+'_{}.pth'.format(args.step)
    #old_model_dir = model_dir+'/'+args.old_model_name+'.pth'

    inputsize = [3, 32, 32]
    taskcla = ([0, 20], [1, 20], [2, 20], [3, 20], [4, 20])

    if args.mode == 'train':
        if args.step == 0:
            model = VGG(inputsize, taskcla).to(device)
        else:
            ## New model
            old_model_dir = model_dir + '/' + args.old_model_name + '_{}.pth'.format(args.step-1)
            model = VGG(inputsize, taskcla).to(device)
            model.load_state_dict(torch.load(old_model_dir), strict=False)

        ## Data of new task
        labeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='once', shuffle=True, target_list=range(args.step*args.nb_cl,(args.step+1)*args.nb_cl))
        labeled_train_loader.dataset.targets = [i - args.step*args.nb_cl for i in labeled_train_loader.dataset.targets]
        labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(args.step*args.nb_cl,(args.step+1)*args.nb_cl))
        labeled_test_loader.dataset.targets = [i - args.step*args.nb_cl for i in labeled_test_loader.dataset.targets]

        #t = 0
        train(model, labeled_train_loader, labeled_test_loader, args)
        eval(model, labeled_test_loader, args)

    elif args.mode == 'test':
        ## Data of new task
        #labeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='once', shuffle=True, target_list=range(0,40))
        labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None, shuffle=False, target_list=range(0,40))
        #labeled_test_loader.dataset.targets = [i - args.step * args.nb_cl for i in labeled_test_loader.dataset.targets]

        model = VGG(inputsize, taskcla).to(device)
        model.load_state_dict(torch.load(args.model_dir), strict=False)
        model.eval()

        ## multi head
        #head = 1
        #eval_multi_head(head, model, labeled_test_loader, args)

        eval_single_head(model, labeled_test_loader, args)
