import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.optim import SGD, lr_scheduler
from torch.autograd import Variable
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from utils.util import cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.vgg_RCL_Side import VGG_tinyimagenet
from modules.module import feat2prob, target_distribution
from data.tinyimagenet_loader import TinyImageNetLoader
from tqdm import tqdm
import numpy as np
import warnings
import os
import scipy.io as sio
import copy



def train(old_model, new_model, train_loader, eva_loader, args):
    optimizer = SGD(new_model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    w = 0
    ce_criterion = nn.CrossEntropyLoss().cuda(args.device)
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        cluster_loss_record = AverageMeter()
        consistent_loss_record = AverageMeter()
        new_model.train()
        old_model.eval()
        exp_lr_scheduler.step()
        for batch_idx, (x, label) in enumerate(train_loader):
            x, label = x.to(args.device), label.to(args.device)
            fc, out_label, out_unlabel = new_model(x, flag=1)

            # CE loss
            label = label - args.num_labeled_classes
            ce_loss = ce_criterion(out_unlabel, label)

            # LwF loss
            _, ref_output = old_model(x)
            soft_target = F.softmax(ref_output / 2, dim=1)
            new_output = old_model.last_label(fc)
            logp = F.log_softmax(new_output / 2, dim=1)
            reg_loss = -torch.mean(torch.sum(soft_target * logp, dim=1))  # * args.T * args.T

            loss = ce_loss + reg_loss

            loss_record.update(loss.item(), x.size(0))
            cluster_loss_record.update(ce_loss.item(), x.size(0))
            consistent_loss_record.update(reg_loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {}, total Loss: {:.4f}, CE Loss: {:.4f}, LwF Loss: {:.4f}'.format(epoch, loss_record.avg, cluster_loss_record.avg, consistent_loss_record.avg))
        _, _, _ = eval_unlabel_classes(new_model, eva_loader, args)

        if (epoch+1) % args.update_interval == 0:
            print('updating target ...')

        if epoch%50==0:
            torch.save(new_model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))
            #sio.savemat(args.save_clusters_path, {'clusters': model.center.data.cpu().numpy()})

def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            label = label - args.num_labeled_classes
            #out = model(x, head=1)
            _, _, out_unlabel = model(x, flag=1)
            prob = F.softmax(out_unlabel, dim=1)
            _, pred = prob.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds = np.append(preds, pred.cpu().numpy())

        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                                  preds)
        print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
        print('-'*100)

    return acc, nmi, ari


def eval_label_classes(model, test_loader, args):
    model.eval()
    preds=np.array([])
    targets=np.array([])
    with torch.no_grad():
        for batch_idx, (x, label) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, _ = model(x, flag=1)
            _, pred = out_label.max(1)
            targets=np.append(targets, label.cpu().numpy())
            preds=np.append(preds, pred.cpu().numpy())
        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets, preds)
        print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_all_classes(model, test_loader, args):
    model.eval()
    preds=np.array([])
    targets=np.array([])
    with torch.no_grad():
        for batch_idx, (x, label) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, out_unlabel = model(x, flag=1)
            output = torch.cat([out_label, out_unlabel], 1)
            _, pred = output.max(1)
            targets=np.append(targets, label.cpu().numpy())
            preds=np.append(preds, pred.cpu().numpy())
        acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets, preds)
        print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='cluster',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--warmup_flag', default=False, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--warmup_lr', type=float, default=0.05)
    parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--warmup_epochs', default=30, type=int)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=5, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    parser.add_argument('--milestones', default=[20, 40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--update_interval', default=50, type=int) ## may be important?
    parser.add_argument('--num_unlabeled_classes', default=20, type=int)
    parser.add_argument('--num_labeled_classes', default=180, type=int)
    parser.add_argument('--n_clusters', default=20, type=int)
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/tinyimagenet_label_pretrain/vgg5+2_tinyimagenet_Baseline_label_180.pth')
    #parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/cifar100_DTC_New/PI/warmup_cifar100_vgg4+2_label_80_unlabel_20.pth')
    parser.add_argument('--dataset_root', type=str, default='/esat/realgar/yliu/Datasets/tiny-imagenet-200/')
    parser.add_argument('--exp_root', type=str, default='./data/experiments/')
    parser.add_argument('--model_name', type=str, default='vgg5+2_tinyimagenet_Fully_supervised_label_180_unlabel_20')
    parser.add_argument('--save_txt_name', type=str, default='Results_vgg5+2_tinyimagenet_Fully_supervised_label_180_unlabel_20.txt')
    parser.add_argument('--save_clusters_name', type=str, default='Clusters_vgg5+2_tinyimagenet_Fully_supervised_label_180_unlabel_20.mat')
    parser.add_argument('--DTC', type=str, default='PI')
    parser.add_argument('--mode', type=str, default='train')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir = args.exp_root + '{}/{}'.format(runner_name, args.DTC)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir + '/' + args.model_name + '.pth'
    args.save_txt_path = args.exp_root + '{}/{}/{}'.format(runner_name, args.DTC, args.save_txt_name)
    args.save_clusters_path = args.exp_root + '{}/{}/{}'.format(runner_name, args.DTC, args.save_clusters_name)

    num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    unlabeled_train_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug='once', shuffle=True, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_val_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None, shuffle=False, target_list = range(args.num_labeled_classes, num_classes))
    unlabeled_test_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='val_folders', aug=None, shuffle=False, target_list=range(args.num_labeled_classes, num_classes))
    labeled_test_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='val_folders', aug=None, shuffle=False, target_list=range(args.num_labeled_classes))
    all_test_loader = TinyImageNetLoader(root=args.dataset_root, batch_size=args.batch_size, split='val_folders', aug=None, shuffle=False, target_list=range(num_classes))

    if args.mode == 'train':
        inputsize = [3, 64, 64]
        #taskcla = ([0, args.num_labeled_classes], [1, args.num_unlabeled_classes])
        old_model = VGG_tinyimagenet(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        old_model.load_state_dict(torch.load(args.pretrain_dir), strict=False)
        for param in old_model.parameters():
            param.requires_grad = False

        new_model = VGG_tinyimagenet(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        new_model = copy.deepcopy(old_model)
        for param in new_model.parameters():
            param.requires_grad = True

        ## Training
        train(old_model, new_model, unlabeled_train_loader, unlabeled_val_loader, args)

        ## Save clusters (args.n_clusters*args.n_clusters)
        ## Save clusters (args.n_clusters*args.n_clusters)
        #sio.savemat(args.save_clusters_path, {'clusters': VGG_unlabel.center.data.cpu().numpy()})
        ## Save model
        torch.save(new_model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

        ## Test
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only = eval_unlabel_classes(new_model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(new_model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(new_model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(new_model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(new_model, all_test_loader, args)
        #print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
        print('[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all, ari_label_all))
        print('[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))

        if args.save_txt:
            with open(args.save_txt_path, 'a') as f:
                #f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write("[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
                f.write("[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_only, nmi_label_only, ari_label_only))
                f.write("[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
                f.write("[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_all, nmi_label_all, ari_label_all))
                f.write("[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_test_all, nmi_test_all, ari_test_all))

    else:
        inputsize = [3, 64, 64]
        new_model = VGG_tinyimagenet(inputsize, args.num_labeled_classes, args.num_unlabeled_classes)
        new_model = new_model.to(args.device)
        ###
        print('Load model ...')
        new_model.load_state_dict(torch.load(args.model_dir))
        new_model.eval()

        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only = eval_unlabel_classes(new_model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(new_model, labeled_test_loader, args)
        acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all = eval_all_classes(new_model, unlabeled_test_loader, args)
        acc_label_all, nmi_label_all, ari_label_all = eval_all_classes(new_model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(new_model, all_test_loader, args)
        #print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
        print('[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_all, nmi_label_all, ari_label_all))
        print('[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))

        if args.save_txt:
            with open(args.save_txt_path, 'a') as f:
                #f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write("[Unlabel Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
                f.write("[Label Test only] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_only, nmi_label_only, ari_label_only))
                f.write("[Unlabel Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_unlabel_all, nmi_unlabel_all, ari_unlabel_all))
                f.write("[Label Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_label_all, nmi_label_all, ari_label_all))
                f.write("[ALL Test split] RCL-DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_test_all, nmi_test_all, ari_test_all))