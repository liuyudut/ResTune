import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import RMSprop, lr_scheduler
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from utils.util import BCE, PairEnum, cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.vgg import VGG_encoder
from data.cifarloader import CIFAR100Loader, CIFAR100LoaderMix
from tqdm import tqdm
import numpy as np
import os


def train(model, train_loader, unlabeled_eval_loader, args):
    #optimizer = SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    optimizer = RMSprop(model.parameters(), lr=args.lr, alpha=0.9)
    #exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    ce_criterion = nn.CrossEntropyLoss().to(args.device)
    bce_criterion = nn.BCEWithLogitsLoss().to(args.device)
    cos_criterion = nn.CosineSimilarity(dim=1, eps=1e-6).to(args.device)
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        model.train()
        #exp_lr_scheduler.step()
        ##
        if epoch<=50:
            for param in model.parameters():
                param.requires_grad = False
            for name,param in model.named_parameters():
                if 'unlabel' in name:
                    param.requires_grad = True
        else:
            for param in model.parameters():
                param.requires_grad = True

        for batch_idx, ((x, _), _, idx) in enumerate(tqdm(train_loader)):
            x = x.to(args.device)
            _, _, out_unlabel = model(x, flag=1)
            out_unlabel = F.softmax(out_unlabel, dim=1)
            out_unlabel = F.normalize(out_unlabel, p=2, dim=1)
            sim_mat = out_unlabel.mm(out_unlabel.t())
            sim_mat = sim_mat.view(-1)
            target = (sim_mat >= args.alpha).long()
            sim_mat_inv = 1 - sim_mat

            #out_unlabel_mat1, out_unlabel_mat2 = PairEnum(out_unlabel)
            # cosine distance
            #sim_mat = cos_criterion(out_unlabel_mat1, out_unlabel_mat1)
            #
            # sim_mat = out_unlabel_mat1 * out_unlabel_mat1
            # #sim_mat_inv = 1.0 - cos_criterion(out_unlabel_mat1, out_unlabel_mat2)
            # #
            # sim_mat_detach = sim_mat.detach()
            # target_zeros = torch.zeros_like(sim_mat_detach).float().to(args.device)
            # target_ones = torch.ones_like(sim_mat_detach).float().to(args.device)
            #alpha = torch.tensor([args.alpha]).to(args.device)
            #target = (sim_mat_detach >= alpha).float()
            #target = torch.where(sim_mat_detach>args.alpha, target_ones, target_zeros).float()
            #sim_mat = sim_mat - 1e-7
            #loss = bce_criterion(sim_mat, target)
            #
            sim_concat = torch.cat((torch.unsqueeze(sim_mat_inv,1), torch.unsqueeze(sim_mat,1)), dim=1)
            loss = ce_criterion(sim_concat, target)
            #eps = 1e-7
            #loss = -(target * torch.log(sim_mat+eps) + (1-target) * torch.log(1-sim_mat)).mean()

            loss_record.update(loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {} Avg Loss: {:.4f}'.format(epoch, loss_record.avg))
        print('[Train split] unlabel classes')
        eval_unlabel_classes(model, unlabeled_eval_loader, args)


def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    for batch_idx, (x, label, _) in enumerate(tqdm(test_loader)):
        x, label = x.to(args.device), label.to(args.device)
        _, _, out_unlabel = model(x, flag=1)
        _, pred = out_unlabel.max(1)
        targets = np.append(targets, label.cpu().numpy())
        preds = np.append(preds, pred.cpu().numpy())
    acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                              preds)
    print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_label_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    for batch_idx, (x, label, _) in enumerate(tqdm(test_loader)):
        x, label = x.to(args.device), label.to(args.device)
        _, out_label, _ = model(x, flag=1)
        _, pred = out_label.max(1)
        targets = np.append(targets, label.cpu().numpy())
        preds = np.append(preds, pred.cpu().numpy())
    acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                              preds)
    print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari

def eval_all_classes(model, test_loader, args):
    model.eval()
    preds = np.array([])
    targets = np.array([])
    for batch_idx, (x, label, _) in enumerate(tqdm(test_loader)):
        x, label = x.to(args.device), label.to(args.device)
        _, out_label, out_unlabel = model(x, flag=1)
        out = torch.cat((out_label, out_unlabel), 1)
        _, pred = out.max(1)
        targets = np.append(targets, label.cpu().numpy())
        preds = np.append(preds, pred.cpu().numpy())
    acc, nmi, ari = cluster_acc(targets.astype(int), preds.astype(int)), nmi_score(targets, preds), ari_score(targets,
                                                                                                              preds)
    print('Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
    return acc, nmi, ari


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='cluster',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    #parser.add_argument('--lr', type=float, default=0.05)
    parser.add_argument('--lr', type=float, default=0.0001)
    parser.add_argument('--gamma', type=float, default=0.5)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-5)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=5, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    # parser.add_argument('--increment_coefficient', type=float, default=0.05)
    parser.add_argument('--milestones', default=[20, 40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--num_unlabeled_classes', default=10, type=int)
    parser.add_argument('--num_labeled_classes', default=80, type=int)
    parser.add_argument('--dataset_root', type=str, default='./data/datasets/CIFAR/')
    parser.add_argument('--exp_root', type=str, default='./data/experiments/')
    parser.add_argument('--pretrain_dir', type=str, default='./data/experiments/cifar100_label_pretrain/vgg4+2_cifar100_PPL_pretrain(10)_label_80.pth')
    parser.add_argument('--topk', default=5, type=int)
    parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    # parser.add_argument('--IL', action='store_true', default=False, help='w/ incremental learning')
    parser.add_argument('--model_name', type=str, default='cifar100_vgg4+2_PPL_label_80_unlabel_10')
    parser.add_argument('--dataset_name', type=str, default='cifar100', help='options: cifar10, cifar100, svhn')
    parser.add_argument('--save_txt_name', type=str,
                        default='PPL_results_cifar100_vgg4+2_label_80_unlabel_10.txt')
    parser.add_argument('--alpha', type=float, default=0.95)
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--mode', type=str, default='train')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir = os.path.join(args.exp_root, runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir + '/' + '{}.pth'.format(args.model_name)
    args.save_txt_path = model_dir + '/' + '{}.pth'.format(args.save_txt_name)

    num_classes = args.num_labeled_classes + args.num_unlabeled_classes
    unlabeled_train_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train',
                                            aug='twice', shuffle=True,
                                            target_list=range(90, 100))
    unlabeled_val_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='train', aug=None,
                                          shuffle=False, target_list=range(90, 100))
    unlabeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None,
                                           shuffle=False, target_list=range(args.num_labeled_classes, num_classes))
    labeled_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None,
                                         shuffle=False, target_list=range(args.num_labeled_classes))
    all_test_loader = CIFAR100Loader(root=args.dataset_root, batch_size=args.batch_size, split='test', aug=None,
                                     shuffle=False, target_list=range(num_classes))

    inputsize = [3, 32, 32]
    model = VGG_encoder(inputsize, args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
    model.load_state_dict(torch.load(args.pretrain_dir), strict=False)
    for param in model.parameters():
        param.requires_grad = True

    if args.mode == 'train':
        ## without joint training of labelled and unlabelled data
        train(model, unlabeled_train_loader, unlabeled_val_loader, args)
        torch.save(model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

        ## Test eval(t, model, test_loader, args, joint=False)
        acc_val, nmi_val, ari_val = eval_unlabel_classes(model, unlabeled_test_loader, args)
        label_acc_test, label_nmi_test, label_ari_test = eval_label_classes(model, labeled_test_loader, args)
        all_acc_test, all_nmi_test, all_ari_test = eval_all_classes(model, all_test_loader, args)
        # print('[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc, init_nmi, init_ari))
        print('[Unlabel classes] PPL: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_val, nmi_val, ari_val))
        # print('[Test split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(init_acc_test, init_nmi_test, init_ari_test))
        print('[Label classes] PPL: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(label_acc_test, label_nmi_test,
                                                                                        label_ari_test))
        print('[ALL classes] PPL: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(all_acc_test, all_nmi_test,
                                                                                      all_ari_test))

        if args.save_txt:
            with open(args.save_txt_path, 'a') as f:
                # f.write("[Train split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc, init_nmi, init_ari))
                f.write("[Unlabel classes] PPL: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(acc_val, nmi_val,
                                                                                                     ari_val))
                # f.write("[Test split] K-means: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(init_acc_test, init_nmi_test, init_ari_test))
                f.write("[Label classes] PPL: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(label_acc_test,
                                                                                                    label_nmi_test,
                                                                                                    label_ari_test))
                f.write("[ALL classes] PPL: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}\n".format(all_acc_test,
                                                                                                  all_nmi_test,
                                                                                                  all_ari_test))
    else:
        print("model loaded from {}.".format(args.model_dir))
        if args.IL:
            model.head1 = nn.Linear(512, num_classes).to(device)
        model.load_state_dict(torch.load(args.model_dir))

