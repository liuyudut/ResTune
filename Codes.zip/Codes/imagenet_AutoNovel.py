import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.optim import SGD, lr_scheduler
from torch.autograd import Variable
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from utils.util import BCE_AutoNovel, PairEnum, cluster_acc, Identity, AverageMeter, seed_torch, str2bool
from utils import ramps
from models.resnet_imagenet import ResNet, BasicBlock, ResNet_unlabel
from modules.module import feat2prob, target_distribution
from data.imagenetloader import ImageNetLoader30, ImageNetLoader882, ImageNetLoader1000
from tqdm import tqdm
import numpy as np
import warnings
import random
import os
warnings.filterwarnings("ignore", category=UserWarning)
import scipy.io as sio
import copy

def train(model, train_loader, unlabeled_eval_loader, args):
    optimizer = SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    exp_lr_scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=args.milestones, gamma=args.gamma)
    criterion1 = nn.CrossEntropyLoss()
    criterion2 = BCE_AutoNovel()
    for epoch in range(args.epochs):
        loss_record = AverageMeter()
        model.train()
        exp_lr_scheduler.step()
        w = args.rampup_coefficient * ramps.sigmoid_rampup(epoch, args.rampup_length)
        for batch_idx, ((x, x_bar),  label, idx) in enumerate(tqdm(train_loader)):
            x, x_bar, label = x.to(args.device), x_bar.to(args.device), label.to(args.device)
            feat, out_label, out_unlabel = model(x, flag=2)
            feat_bar, out_label_bar, out_unlabel_bar = model(x_bar, flag=2)
            prob2, prob2_bar = F.softmax(out_unlabel, dim=1), F.softmax(out_unlabel_bar, dim=1)

            #mask_lb = label<args.num_labeled_classes

            rank_feat = (feat).detach()
            rank_idx = torch.argsort(rank_feat, dim=1, descending=True)
            rank_idx1, rank_idx2= PairEnum(rank_idx)
            rank_idx1, rank_idx2=rank_idx1[:, :args.topk], rank_idx2[:, :args.topk]
            rank_idx1, _ = torch.sort(rank_idx1, dim=1)
            rank_idx2, _ = torch.sort(rank_idx2, dim=1)

            rank_diff = rank_idx1 - rank_idx2
            rank_diff = torch.sum(torch.abs(rank_diff), dim=1)
            target_ulb = torch.ones_like(rank_diff).float().to(args.device)
            target_ulb[rank_diff>0] = -1

            prob1_ulb, _= PairEnum(prob2)
            _, prob2_ulb = PairEnum(prob2_bar)

            #loss_ce = criterion1(output1[mask_lb], label[mask_lb])
            loss_bce = criterion2(prob1_ulb, prob2_ulb, target_ulb)
            consistency_loss = F.mse_loss(prob2, prob2_bar) # F.mse_loss(prob1, prob1_bar) +
            loss = loss_bce + w * consistency_loss

            loss_record.update(loss.item(), x.size(0))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print('Train Epoch: {} Avg Loss: {:.4f}'.format(epoch, loss_record.avg))
        print('[Train split] unlabel classes')
        eval_unlabel_classes(model, unlabeled_eval_loader, args)
        if epoch % 20 == 0:
            torch.save(model.state_dict(), args.model_dir)
            print("model saved to {}.".format(args.model_dir))

def eval_unlabel_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            #out = model(x, head=1)
            _, _, out_unlabel = model(x, flag=2)
            prob_pca = feat2prob(out_unlabel, model.center)
            _, pred_pca = prob_pca.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            idx = idx.data.cpu().numpy()
            #feats[idx, :] = feat.cpu().detach().numpy()
            probs_pca[idx, :] = prob_pca.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[Unlabel Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))
        probs_pca = torch.from_numpy(probs_pca)

    return acc, nmi, ari, probs_pca

def eval_label_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, _ = model(x, flag=2)
            _, pred_pca = out_label.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            #feats[idx, :] = feat.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[Label Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))

    return acc, nmi, ari

def eval_all_classes(model, test_loader, args):
    model.eval()
    preds_pca = np.array([])
    targets = np.array([])
    #feats = np.zeros((len(test_loader.dataset), args.n_clusters))
    #probs_pca = np.zeros((len(test_loader.dataset), args.n_clusters))
    with torch.no_grad():
        for batch_idx, (x, label, idx) in enumerate(tqdm(test_loader)):
            x, label = x.to(args.device), label.to(args.device)
            _, out_label, out_unlabel = model(x, flag=2)
            out_unlabel = feat2prob(out_unlabel, model.center)
            out_cat = torch.cat([out_label, out_unlabel], dim=1)
            _, pred_pca = out_cat.max(1)
            targets = np.append(targets, label.cpu().numpy())
            preds_pca = np.append(preds_pca, pred_pca.cpu().numpy())
            #feats[idx, :] = feat.cpu().detach().numpy()
        acc, nmi, ari = cluster_acc(targets.astype(int), preds_pca.astype(int)), nmi_score(targets, preds_pca), ari_score(targets,
                                                                                                                  preds_pca)
        print('[Label Classes] Test acc {:.4f}, nmi {:.4f}, ari {:.4f}'.format(acc, nmi, ari))

    return acc, nmi, ari

def copy_param(model, pretrain_dir, loc=None):
    pre_dict = torch.load(pretrain_dir)
    new=list(pre_dict.items())
    model_kvpair=model.state_dict()
    if loc is not None:
        count=0
        for key, value in model_kvpair.items()[:loc]:
            layer_name,weights=new[count]
            model_kvpair[key]=weights
            count+=1
    else:
        count=0
        for key, value in model_kvpair.items():
            layer_name,weights=new[count]
            model_kvpair[key]=weights
            count+=1
    model.load_state_dict(model_kvpair, strict=False)
    return model

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
            description='cluster',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--warmup_flag', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--warmup_lr', type=float, default=0.1)
    parser.add_argument('--lr', type=float, default=0.1)
    parser.add_argument('--gamma', type=float, default=0.1)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--rampup_length', default=50, type=int)
    parser.add_argument('--rampup_coefficient', type=float, default=10.0)
    parser.add_argument('--milestones', default=[40, 60, 80], type=int, nargs='+')
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--update_interval', default=5, type=int)
    parser.add_argument('--num_unlabeled_classes', default=30, type=int)
    parser.add_argument('--num_labeled_classes', default=882, type=int)
    parser.add_argument('--n_clusters', default=30, type=int)
    parser.add_argument('--seed', default=1, type=int)
    parser.add_argument('--topk', default=5, type=int)
    #parser.add_argument('--save_txt', default=True, type=str2bool, help='save txt or not', metavar='BOOL')
    parser.add_argument('--pretrain_dir', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/experiments/pretrained/resnet18_imagenet_classif_882_ICLR18.pth')
    parser.add_argument('--dataset_split', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/datasets/ImageNet/')
    #parser.add_argument('--dataset_root', type=str, default='/esat/visicsrodata/datasets/ilsvrc2012/')
    parser.add_argument('--dataset_root', type=str, default='/esat/realgar/yliu/Datasets/ImageNet/')
    parser.add_argument('--exp_root', type=str, default='/esat/realgar/yliu/Codes/object_discovery/data/experiments/')
    parser.add_argument('--model_name', type=str, default='resnet18_imagenet_DTC_label_882_unlabel_30_C')
    #parser.add_argument('--trained_dir', type=str, default='/esat/realgar/yliu/Codes/DTC-master/data/experiments/imagenet_DTC/Baseline/Baseline_run_C.pth')
    parser.add_argument('--unlabeled_subset', type=str, default='C')
    #parser.add_argument('--test_model_dir', type=str, default='/esat/realgar/yliu/Codes/DTC-master/data/experiments/cifar10_DTC/PI/PI_run_1.pth')
    parser.add_argument('--save_txt_name', type=str, default='Result_resnet18_imagenet_DTC_label_882_unlabel_30.txt')
    parser.add_argument('--mode', type=str, default='train')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    args.device = torch.device("cuda" if args.cuda else "cpu")
    seed_torch(args.seed)

    runner_name = os.path.basename(__file__).split(".")[0]
    model_dir= args.exp_root + '{}'.format(runner_name)
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    args.model_dir = model_dir+'/'+args.model_name+'.pth'
    args.save_txt_path= args.exp_root+ '{}/{}'.format(runner_name, args.save_txt_name)

    unlabeled_train_loader = ImageNetLoader30(args.batch_size, num_workers=8, path='/esat/visicsrodata/datasets/ilsvrc2012/', splits = args.dataset_split,
                                             subset=args.unlabeled_subset, aug='twice', shuffle=True, subfolder='ILSVRC2012_img_train')
    all_test_loader = ImageNetLoader1000(args.batch_size, num_workers=8, path=args.dataset_root, splits = args.dataset_split,
                                            aug=None, shuffle=False, subfolder='ILSVRC2012_img_val')
    labeled_test_loader = ImageNetLoader882(args.batch_size, num_workers=8, path=args.dataset_root, splits = args.dataset_split,
                                            aug=None, shuffle=False, subfolder='ILSVRC2012_img_val')
    unlabeled_test_loader = ImageNetLoader30(args.batch_size, num_workers=8, path=args.dataset_root, splits = args.dataset_split,
                                             subset=args.unlabeled_subset, aug=None, shuffle=False, subfolder='ILSVRC2012_img_val')

    if args.mode == 'train':

        model = ResNet_unlabel(BasicBlock, [2, 2, 2, 2], args.num_labeled_classes, args.num_unlabeled_classes).to(args.device)
        #model = copy_param(model, args.pretrain_dir)
        model.load_state_dict(torch.load(args.pretrain_dir), strict=False)
        for name, param in model.named_parameters():
            if 'last' not in name and 'layer4' not in name:
                param.requires_grad = False


        train(model, unlabeled_train_loader, unlabeled_test_loader, args)

        ## save
        #sio.savemat(args.save_clusters_path, {'clusters': model.center.data.cpu().numpy()})
        ## Save model
        torch.save(model.state_dict(), args.model_dir)
        print("model saved to {}.".format(args.model_dir))

    else:
        model = ResNet_unlabel(BasicBlock, [2, 2, 2, 2], nclass_label=args.num_labeled_classes,nclass_unlabel=args.num_unlabeled_classes).to(args.device)
        print('Load model ...')
        model.load_state_dict(torch.load(args.trained_dir))
        model.eval()
        ##

        ##
        acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only, _ = eval_unlabel_classes(model, unlabeled_test_loader, args)
        acc_label_only, nmi_label_only, ari_label_only = eval_label_classes(model, labeled_test_loader, args)
        acc_test_all, nmi_test_all, ari_test_all = eval_all_classes(model, all_test_loader, args)
        print('[Unlabel Test only] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_unlabel_only, nmi_unlabel_only, ari_unlabel_only))
        print('[Label Test only] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_label_only, nmi_label_only, ari_label_only))
        print('[ALL Test split] DTC: ACC {:.4f}, NMI {:.4f}, ARI {:.4f}'.format(acc_test_all, nmi_test_all, ari_test_all))